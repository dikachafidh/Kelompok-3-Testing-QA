import { BASE, KNOWN, clickProduct, detailOpen, sleep, MOBILE, DESKTOP, openPage, bodyText, titles, clickText, iconButtons, addProduct, openCart, fill, searchProduct, goCheckout, shot } from './lib.mjs';
export const TCS = [];
const tc = (id, fn, opts = {}) => TCS.push({ id, fn, ...opts });
const HOME = 'Solusi Produk Digital Instan & Jasa Kustom', KAT = 'Katalog Produk Digital', LAY = 'Halaman Status, Estimasi & Tagihan Kustom';
const has = async (p, s) => (await bodyText(p)).includes(s);
const EBOOKS = ['7 Jurus Sakti Kata Sambutan', 'Kumpulan Rumus Matematika SMA'];

// ---------------- NAVIGASI ----------------
tc('NAV-01', async (p) => {
  await openPage(p); const r = []; let ok = true; let activeOk = true;
  const marks = { Home: HOME, Katalog: KAT, Layanan: LAY };
  for (const [tab, mk] of Object.entries(marks)) {
    await clickText(p, tab); await sleep(700);
    const shown = await has(p, mk); ok = ok && shown;
    const sig = await p.evaluate((t) => { const bs = [...document.querySelectorAll('button')].filter((b) => b.offsetParent && ['Home', 'Katalog', 'Layanan'].includes(b.innerText.trim())); const st = (b) => { const c = getComputedStyle(b), i = b.querySelector('svg'); return c.color + '|' + c.backgroundColor + '|' + c.fontWeight + '|' + (i ? getComputedStyle(i).color : ''); }; const me = bs.filter((b) => b.innerText.trim() === t).map(st); const others = bs.filter((b) => b.innerText.trim() !== t).map(st); return { me: me[me.length - 1], differs: others.length > 0 && others.every((o) => o !== me[me.length - 1]) }; }, tab);
    activeOk = activeOk && sig.differs; r.push(`${tab}: ${shown ? 'bagian benar' : 'SALAH'}, ditandai: ${sig.differs}`);
  }
  return { ok: ok && activeOk, actual: r.join('; '), shot: await shot(p, 'NAV-01') };
});
tc('NAV-02', async (p) => {
  await openPage(p); const r = []; let ok = true;
  const bar = await p.evaluate(() => { const bs = [...document.querySelectorAll('button')].filter((b) => b.offsetParent && ['Home', 'Katalog', 'Layanan'].includes(b.innerText.trim())); return bs.map((b) => ({ t: b.innerText.trim(), top: Math.round(b.getBoundingClientRect().top) })); });
  const bottomBar = bar.filter((b) => b.top > 700); ok = bottomBar.length === 3; r.push(`item bilah bawah terlihat: ${bottomBar.length}/3`);
  for (const [tab, mk] of [['Katalog', KAT], ['Layanan', LAY], ['Home', HOME]]) { await clickText(p, tab); await sleep(600); const s = await has(p, mk); ok = ok && s; r.push(`${tab}:${s ? 'ok' : 'SALAH'}`); }
  await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await sleep(400);
  const overlap = await p.evaluate(() => { const l = [...document.querySelectorAll('a')].find((a) => a.innerText.includes('laporkan')); const bs = [...document.querySelectorAll('button')].filter((b) => b.offsetParent && b.innerText.trim() === 'Home'); if (!l || !bs.length) return 'n/a'; const lr = l.getBoundingClientRect(); const br = bs[bs.length - 1].getBoundingClientRect(); return lr.bottom <= br.top + 4 ? 'tidak menutupi' : 'MENUTUPI'; });
  ok = ok && overlap !== 'MENUTUPI'; r.push(`bilah vs footer: ${overlap}`);
  return { ok, actual: r.join('; '), shot: await shot(p, 'NAV-02') };
});
tc('NAV-03', async (p) => { await openPage(p); await clickText(p, 'Katalog'); await sleep(600); const before = await has(p, KAT); await clickText(p, 'RizzFlow'); await sleep(700); const after = await has(p, HOME); return { ok: before && after, actual: `dari Katalog (${before}) klik logo -> beranda: ${after}`, shot: await shot(p, 'NAV-03') }; });
tc('NAV-04', async (p) => { await openPage(p); await clickText(p, 'Jelajahi Katalog'); await sleep(700); const s = await has(p, KAT); return { ok: s, actual: `Jelajahi Katalog -> bagian Katalog tampil: ${s}`, shot: await shot(p, 'NAV-04') }; });
tc('NAV-05', async (p) => { await openPage(p); await clickText(p, 'Layanan Kustom & Garansi'); await sleep(700); const s = await has(p, LAY); const g = await has(p, 'Garansi'); return { ok: s && g, actual: `menuju Layanan: ${s}; teks garansi tersedia: ${g}`, shot: await shot(p, 'NAV-05') }; });
tc('NAV-06', async (p) => { await openPage(p); const ok1 = await clickText(p, 'Lihat Semua'); await sleep(800); const t = await bodyText(p); const kat = t.includes(KAT); const cats = ['Akun Premium', 'E-Book', 'Template Excel', 'Template PPT'].every((c) => t.includes(c)); return { ok: ok1 && kat, actual: `klik Lihat Semua: ${ok1}; halaman Katalog: ${kat}; 4 kategori terlihat: ${cats}; judul produk: ${(await titles(p)).length}`, shot: await shot(p, 'NAV-06') }; });
tc('NAV-07', async (p) => { await openPage(p); await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); const h = await p.evaluate(() => { const a = [...document.querySelectorAll('a')].find((x) => x.innerText.includes('laporkan')); return a ? a.getAttribute('href') : null; }); const ok = h === 'mailto:rizzflow55@gmail.com?subject=Laporan%20Website%20RizzFlow'; return { ok, actual: `href tautan laporkan: ${h}`, shot: await shot(p, 'NAV-07') }; });
tc('NAV-08', async (p) => {
  await openPage(p); await clickText(p, 'Cek Pesanan Kustom'); await sleep(800);
  const a = (await has(p, LAY)) && !!(await p.$('input[placeholder^="Ketik Kode Pesanan"]'));
  await clickText(p, 'Home'); await sleep(600); await clickText(p, 'Pesan / Cek Kode Kustom'); await sleep(800);
  const b = (await has(p, LAY)) && !!(await p.$('input[placeholder^="Ketik Kode Pesanan"]'));
  return { ok: a && b, actual: `Cek Pesanan Kustom (header) -> form kode: ${a}; Pesan / Cek Kode Kustom -> form kode: ${b}`, shot: await shot(p, 'NAV-08') };
});
tc('NAV-09', async (p) => {
  await openPage(p); await addProduct(p, 0); await clickText(p, 'Katalog'); await sleep(500); await clickProduct(p, 'Kumpulan Rumus Matematika SMA'); await sleep(900);
  const url0 = p.url();
  await p.goBack().catch(() => null); await sleep(600); const u1 = p.url();
  await p.goBack().catch(() => null); await sleep(600); const u2 = p.url();
  await p.goForward().catch(() => null); await sleep(600); const u3 = p.url();
  const same = [u1, u2, u3].every((u) => u.startsWith(BASE));
  const t = await bodyText(p); const cartKept = /Keranjang Belanja/.test(t) || (await p.evaluate(() => JSON.stringify(localStorage)).then((s) => s.length > 2));
  return { ok: same && cartKept, actual: `URL awal ${url0}; setelah Back: ${u1}; Back lagi: ${u2}; Forward: ${u3}; tetap di situs: ${same}; keranjang bertahan: ${cartKept}`, shot: await shot(p, 'NAV-09') };
});

// ---------------- PENCARIAN ----------------
const hasAll = (arr, subs) => subs.every((s) => arr.some((t) => t.includes(s)));
tc('SRC-01', async (p) => { await openPage(p); await searchProduct(p, 'excel'); const t = await titles(p); return { ok: t.some((x) => x.includes('Template Excel UMKM')), actual: `hasil untuk "excel": ${JSON.stringify(t)}`, shot: await shot(p, 'SRC-01') }; });
tc('SRC-02', async (p) => { await openPage(p); await searchProduct(p, 'zzzqxv'); const t = await titles(p); const msg = /belum ditemukan|tidak ditemukan|tidak ada|belum ada|kosong/i.test(await bodyText(p)); return { ok: t.length === 0 && msg, actual: `judul produk tampil: ${t.length}; pesan tidak ditemukan: ${msg}`, shot: await shot(p, 'SRC-02') }; });
tc('SRC-03', async (p) => { await openPage(p); await searchProduct(p, ''); const t = await titles(p); return { ok: p.__errs.length === 0, actual: `pencarian kosong: ${t.length} produk tampil; galat konsol: ${p.__errs.length}`, shot: await shot(p, 'SRC-03') }; });
tc('SRC-04', async (p) => { await openPage(p); await searchProduct(p, 'a'); const t1 = (await titles(p)).length; await searchProduct(p, 'x'.repeat(100)); const t2 = (await titles(p)).length; const ok = p.__errs.length === 0; return { ok, actual: `"a": ${t1} hasil; 100 karakter: ${t2} hasil; galat: ${p.__errs.length}`, shot: await shot(p, 'SRC-04') }; });
tc('SRC-05', async (p) => { await openPage(p); await searchProduct(p, 'EBOOK'); const a = await titles(p); await searchProduct(p, 'ebook'); const b = await titles(p); return { ok: JSON.stringify(a) === JSON.stringify(b), actual: `EBOOK: ${a.length} hasil; ebook: ${b.length} hasil; sama: ${JSON.stringify(a) === JSON.stringify(b)}`, shot: await shot(p, 'SRC-05') }; });
tc('SRC-06', async (p) => { await openPage(p); await searchProduct(p, '  rumus  '); const a = await titles(p); await searchProduct(p, `' " < > & %`); const t = await bodyText(p); const lit = (await p.evaluate(() => document.querySelector('input[placeholder^="Cari e-book"]').value)).includes('<'); return { ok: p.__errs.length === 0 && lit, actual: `spasi ganda -> ${a.length} hasil (${a[0] || '-'}); karakter spesial tampil sebagai teks: ${lit}; galat: ${p.__errs.length}`, shot: await shot(p, 'SRC-06') }; });
tc('SRC-07', async (p) => { await openPage(p); await searchProduct(p, 'rumus'); const t = await titles(p); return { ok: t.length === 1 && t[0].includes('Kumpulan Rumus Matematika SMA'), actual: `hasil "rumus": ${JSON.stringify(t)}`, shot: await shot(p, 'SRC-07') }; });

// ---------------- KATALOG ----------------
const goKatalog = async (p) => { await openPage(p); await clickText(p, 'Katalog'); await sleep(800); };
tc('CAT-01', async (p) => { await goKatalog(p); const t = await titles(p); const body = await bodyText(p); const prices = ['Rp5.000', 'Rp19.000', 'Rp29.000'].every((x) => body.includes(x)); const lab = /Semua \((\d+)\)/.exec(body); return { ok: t.length === 3 && prices && lab && Number(lab[1]) === t.length, actual: `${t.length} produk; label "${lab ? lab[0] : '-'}"; harga Rp5.000/Rp19.000/Rp29.000 tampil: ${prices}`, shot: await shot(p, 'CAT-01') }; });
tc('CAT-02', async (p) => { await goKatalog(p); await clickText(p, 'E-Book'); await sleep(800); const t = await titles(p); return { ok: t.length === 2 && hasAll(t, EBOOKS), actual: `kategori E-Book: ${JSON.stringify(t)}`, shot: await shot(p, 'CAT-02') }; });
tc('CAT-03', async (p) => { await goKatalog(p); await clickText(p, 'Template Excel'); await sleep(800); const t = await titles(p); return { ok: t.length === 1 && t[0].includes('Template Excel UMKM'), actual: `kategori Template Excel: ${JSON.stringify(t)}`, shot: await shot(p, 'CAT-03') }; });
tc('CAT-04', async (p) => {
  await goKatalog(p); const r = []; let ok = true;
  for (const c of ['Akun Premium', 'Template PPT']) { await clickText(p, c); await sleep(800); const t = await titles(p); const body = await bodyText(p); const msg = /belum ditemukan|belum ada|tidak ada|kosong|tidak ditemukan|segera hadir/i.test(body); ok = ok && t.length === 0 && msg; r.push(`${c}: ${t.length} produk, pesan kosong: ${msg}`); }
  return { ok, actual: r.join('; '), shot: await shot(p, 'CAT-04') };
});
tc('CAT-05', async (p) => {
  await goKatalog(p);
  const res = await p.evaluate((known) => {
    const leaf = (txt) => [...document.querySelectorAll('h1,h2,h3,h4,p,span,div')].filter((e) => e.children.length === 0 && e.innerText && e.innerText.trim() === txt && e.getBoundingClientRect().width > 0);
    const ownerOf = (badgeEl) => { let n = badgeEl; for (let i = 0; i < 8 && n; i++, n = n.parentElement) { const hit = known.find((k) => (n.innerText || '').includes(k)); if (hit) { const others = known.filter((k) => (n.innerText || '').includes(k)); if (others.length === 1) return hit; } } return null; };
    const out = {}; let overlaps = 0;
    for (const bt of ['Baru', 'Terlaris']) for (const e of leaf(bt)) { const o = ownerOf(e); out[bt] = o; const t = o && leaf(o)[0]; if (t) { const r = e.getBoundingClientRect(), hr = t.getBoundingClientRect(); if (r.left < hr.right && r.right > hr.left && r.top < hr.bottom && r.bottom > hr.top) overlaps++; } }
    return { out, overlaps };
  }, KNOWN);
  const baruOk = (res.out.Baru || '').startsWith('7 Jurus'); const larisOk = (res.out.Terlaris || '').startsWith('Template Excel');
  return { ok: baruOk && larisOk && res.overlaps === 0, actual: `lencana Baru pada: ${res.out.Baru || '-'}; Terlaris pada: ${res.out.Terlaris || '-'}; lencana menimpa judul: ${res.overlaps}`, shot: await shot(p, 'CAT-05') };
});

// ---------------- DETAIL PRODUK ----------------
const openDetail = async (p, name) => { await goKatalog(p); await clickProduct(p, name); await sleep(900); };
tc('PRD-01', async (p) => { await openDetail(p, 'Kumpulan Rumus Matematika SMA'); const t = await bodyText(p); const ok = (await detailOpen(p)) && t.includes('Deskripsi') && t.includes('Rp19.000'); return { ok, actual: `detail terbuka: tombol Tambah ke Keranjang, tab Deskripsi, harga Rp19.000 tampil = ${ok}`, shot: await shot(p, 'PRD-01') }; });
tc('PRD-02', async (p) => {
  await goKatalog(p); const before = await bodyText(p); const kartuHarga = before.includes('Rp29.000');
  await clickProduct(p, 'Template Excel UMKM'); await sleep(900); const det = await bodyText(p); const opened = await detailOpen(p);
  const desc = 'penghitung harga jual dan keuntungan'; const ok = opened && kartuHarga && det.includes('Template Excel UMKM') && det.includes('Rp29.000') && det.includes(desc);
  return { ok, actual: `harga di kartu Rp29.000: ${kartuHarga}; detail memuat nama, Rp29.000, dan deskripsi yang sama: ${det.includes('Rp29.000') && det.includes(desc)}`, shot: await shot(p, 'PRD-02') };
});
tc('PRD-04', async (p) => {
  await goKatalog(p); await clickText(p, 'E-Book'); await sleep(700); await clickProduct(p, 'Kumpulan Rumus Matematika SMA'); await sleep(900); const wasOpen = await detailOpen(p);
  const closed = await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.offsetParent && x.querySelector('svg.lucide-x')); if (b) { b.click(); return true; } return false; });
  await sleep(700); const t = await titles(p); const detailGone = !(await has(p, 'Cara Akses'));
  return { ok: wasOpen && closed && detailGone && t.length === 2, actual: `detail sempat terbuka: ${wasOpen}; tombol tutup ditemukan: ${closed}; detail tertutup: ${detailGone}; filter E-Book tetap (${t.length} produk)`, shot: await shot(p, 'PRD-04') };
});
