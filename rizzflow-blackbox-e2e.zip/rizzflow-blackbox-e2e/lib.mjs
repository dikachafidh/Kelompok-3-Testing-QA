import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
export const BASE = 'http://localhost:3000';
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const MOBILE = { width: 390, height: 844, deviceScaleFactor: 1, isMobile: true, hasTouch: true };
export const DESKTOP = { width: 1366, height: 768, deviceScaleFactor: 1 };

export async function launch() {
  return puppeteer.launch({ args: chromium.args, executablePath: await chromium.executablePath(), headless: 'shell' });
}
export async function newPage(browser, viewport = MOBILE) {
  const page = await browser.newPage();
  await page.setViewport(viewport);
  page.__errs = []; page.__reqs = []; page.__dialogs = 0;
  page.on('request', (r) => page.__reqs.push(r.method() + ' ' + r.url()));
  page.on('dialog', async (d) => { page.__dialogs++; await d.dismiss(); });
  page.on('pageerror', (e) => page.__errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') page.__errs.push('console: ' + m.text().slice(0, 160)); });
  return page;
}
export const openPage = async (p, url = '/') => { await p.goto(url.startsWith('http') ? url : BASE + url, { waitUntil: 'networkidle2', timeout: 90000 }); await sleep(500); };
export const bodyText = (p) => p.evaluate(() => document.body.innerText.replace(/\n+/g, ' | '));
export const KNOWN = ['7 Jurus Sakti Kata Sambutan - Siap Pakai Untuk Segala Acara !', 'Kumpulan Rumus Matematika SMA', 'Template Excel UMKM'];
export const titles = (p) => p.evaluate((known) => {
  const vis = (e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  return known.filter((k) => [...document.querySelectorAll('h1,h2,h3,h4,p,span,div')].some((e) => e.children.length === 0 && e.innerText && e.innerText.trim() === k && vis(e)));
}, KNOWN);
export const clickText = (p, txt, exact = true) => p.evaluate((t, ex) => {
  const els = [...document.querySelectorAll('button,a,h3')].filter((e) => e.offsetParent !== null);
  const el = els.find((e) => { const x = (e.innerText || '').trim().replace(/\s+/g, ' '); return ex ? x === t : x.includes(t); });
  if (el) { el.click(); return true; } return false;
}, txt, exact);
export async function iconButtons(p) {
  const out = [];
  for (const b of await p.$$('button')) {
    const [t, v] = await b.evaluate((e) => [(e.innerText || '').trim(), e.offsetParent !== null]);
    if (!t && v) out.push(b);
  }
  return out;
}
export async function addProduct(p, idx) { const ic = await iconButtons(p); await ic[idx].click(); await sleep(500); }
export const openCart = async (p) => { const ok = await clickText(p, 'Keranjang Belanja', false); await sleep(900); return ok; };
export async function fill(p, sel, val) {
  await p.waitForSelector(sel, { timeout: 8000 });
  await p.evaluate((s, v) => {
    const el = document.querySelector(s);
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }, sel, val);
  await sleep(250);
}
export async function searchProduct(p, q) {
  await fill(p, 'input[placeholder^="Cari e-book"]', q);
  await p.focus('input[placeholder^="Cari e-book"]'); await p.keyboard.press('Enter'); await sleep(900);
}
export async function goCheckout(p) {
  await clickText(p, 'Lanjut ke Pembayaran QRIS');
  for (let i = 0; i < 40; i++) { await sleep(400); if ((await p.evaluate(() => location.pathname)) === '/checkout') break; }
  await sleep(1200);
}
export async function shot(p, id, suffix = '') {
  const f = `${id}${suffix}.png`;
  await p.screenshot({ path: path.join('./evidence', f) });
  return f;
}
export async function runAxe(p) {
  await p.addScriptTag({ path: require.resolve('axe-core/axe.min.js') });
  return p.evaluate(async () => { const r = await window.axe.run(document, { runOnly: ['wcag2a', 'wcag2aa'] }); return r.violations.map((v) => ({ id: v.id, impact: v.impact, n: v.nodes.length, help: v.help })); });
}

export const clickProduct = (p, name) => p.evaluate((t) => {
  const els = [...document.querySelectorAll('h1,h2,h3,h4,p,span,div')].filter((e) => e.children.length === 0 && (e.innerText || '').trim().startsWith(t) && e.getBoundingClientRect().width > 0);
  const el = els[0]; if (!el) return false; el.click(); return true;
}, name);
export const detailOpen = async (p) => { const t = await bodyText(p); return t.includes('Cara Akses') && t.includes('Tambah ke Keranjang'); };
