import fs from 'node:fs';
import { BASE, KNOWN, sleep, MOBILE, DESKTOP, openPage, bodyText, titles, clickText, clickProduct, iconButtons, addProduct, openCart, fill, goCheckout, shot, runAxe } from './lib.mjs';
export const TCS = [];
const tc = (id, fn, opts = {}) => TCS.push({ id, fn, ...opts });
const overflow = (p) => p.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
const EMAIL = 'input[placeholder^="Contoh: nama@email.com"]';
const flow = async (p) => {
  const r = []; await openPage(p); r.push(`beranda ${await overflow(p) <= 1 ? 'tanpa scroll horizontal' : 'OVERFLOW'}`);
  await clickText(p, 'Katalog'); await sleep(700); const kat = (await bodyText(p)).includes('Katalog Produk Digital'); r.push(`katalog ${kat ? 'ok' : 'GAGAL'}`);
  await addProduct(p, 0); const cart = /1 \| Keranjang Belanja/.test(await bodyText(p)); r.push(`tambah keranjang ${cart ? 'ok' : 'GAGAL'}`);
  await openCart(p); await goCheckout(p); const co = p.url().endsWith('/checkout') && !!(await p.$(EMAIL)); r.push(`checkout ${co ? 'ok' : 'GAGAL'}`);
  return { ok: kat && cart && co && p.__errs.filter((e) => e.startsWith('pageerror')).length === 0, text: r.join('; ') };
};
tc('CMP-01', async (p) => { const r = await flow(p); return { ok: r.ok, actual: `Chromium 153 (desktop 1366x768): ${r.text}; pageerror: ${p.__errs.filter((e) => e.startsWith('pageerror')).length}`, shot: await shot(p, 'CMP-01') }; }, { viewport: DESKTOP });
tc('CMP-02', async () => ({ status: 'Blocked', actual: 'Firefox tidak tersedia di lingkungan pengujian ini; perlu dijalankan pada perangkat penguji.', shot: '' }));
tc('CMP-03', async () => ({ status: 'Blocked', actual: 'Microsoft Edge tidak tersedia di lingkungan pengujian ini; perlu dijalankan pada perangkat penguji.', shot: '' }));
tc('CMP-04', async (p) => { const r = await flow(p); return { status: 'Blocked', actual: `Emulasi layar HP 390x844 di Chromium: ${r.text}. Perangkat Android nyata belum diuji sehingga status tidak dinyatakan Pass.`, shot: await shot(p, 'CMP-04') }; });
tc('CMP-05', async () => ({ status: 'Blocked', actual: 'Safari iOS dan perangkat iPhone tidak tersedia.', shot: '' }));
tc('CMP-06', async (p) => {
  const res = []; let ok = true; const files = [];
  for (const w of [375, 768, 1366, 1920]) { await p.setViewport({ width: w, height: w < 800 ? 812 : 900, deviceScaleFactor: 1 }); await openPage(p); const o1 = await overflow(p); await clickText(p, 'Katalog'); await sleep(600); const o2 = await overflow(p); ok = ok && o1 <= 1 && o2 <= 1; res.push(`${w}px: beranda ${o1 <= 1 ? 'ok' : 'overflow ' + o1}, katalog ${o2 <= 1 ? 'ok' : 'overflow ' + o2}`); files.push(await shot(p, 'CMP-06', '_' + w)); }
  return { ok, actual: res.join('; ') + '; bukti: ' + files.join(', '), shot: files[files.length - 1] };
});
tc('CMP-07', async (p) => {
  await p.setViewport({ width: 683, height: 384, deviceScaleFactor: 2 }); await openPage(p); const o = await overflow(p);
  const vis = await p.evaluate(() => ({ cari: !!document.querySelector('input[placeholder^="Cari e-book"]'), tab: [...document.querySelectorAll('button')].filter((b) => b.offsetParent && ['Home', 'Katalog', 'Layanan'].includes(b.innerText.trim())).length }));
  return { ok: o <= 1 && vis.cari && vis.tab >= 3, actual: `emulasi zoom 200% (viewport CSS 683x384, skala 2): scroll horizontal ${o <= 1 ? 'tidak ada' : o + 'px'}; kolom cari terlihat: ${vis.cari}; tab navigasi terlihat: ${vis.tab}`, shot: await shot(p, 'CMP-07') };
});

// ---------------- AKSESIBILITAS ----------------
tc('ACC-01', async (p) => {
  await openPage(p); await clickText(p, 'Katalog'); await sleep(700);
  const r = await p.evaluate(() => { const imgs = [...document.querySelectorAll('img')]; return { n: imgs.length, noAttr: imgs.filter((i) => !i.hasAttribute('alt')).map((i) => i.src.split('/').pop().slice(0, 24)), empty: imgs.filter((i) => i.getAttribute('alt') === '').length, alts: imgs.map((i) => i.getAttribute('alt')).slice(0, 6) }; });
  return { ok: r.noAttr.length === 0 && r.empty === 0, actual: `${r.n} gambar; tanpa atribut alt: ${r.noAttr.length}; alt kosong: ${r.empty}; contoh alt: ${JSON.stringify(r.alts)}`, shot: await shot(p, 'ACC-01') };
});
tc('ACC-02', async (p) => {
  await openPage(p); const hs = await p.evaluate(() => [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter((h) => h.getBoundingClientRect().width > 0 || true).map((h) => h.tagName + ':' + h.innerText.trim().slice(0, 24)));
  const lv = hs.map((h) => Number(h[1])); const h1 = lv.filter((x) => x === 1).length; let skip = false; for (let i = 1; i < lv.length; i++) if (lv[i] - lv[i - 1] > 1) skip = true;
  return { ok: h1 === 1 && !skip, actual: `jumlah H1: ${h1}; lompatan level heading: ${skip}; urutan: ${hs.slice(0, 8).join(' > ')}`, shot: await shot(p, 'ACC-02') };
}, { viewport: DESKTOP });
tc('ACC-03', async (p) => {
  await openPage(p); const stops = [];
  for (let i = 0; i < 45; i++) { await p.keyboard.press('Tab'); const s = await p.evaluate(() => { const e = document.activeElement; if (!e || e === document.body) return null; const cs = getComputedStyle(e); const label = (e.innerText || e.getAttribute('aria-label') || e.placeholder || e.tagName).trim().replace(/\s+/g, ' ').slice(0, 24); return { label, tag: e.tagName, icon: e.tagName === 'BUTTON' && !(e.innerText || '').trim(), ring: cs.outlineStyle !== 'none' || (cs.boxShadow && cs.boxShadow !== 'none') }; }); if (s) stops.push(s); }
  const labels = stops.map((s) => s.label); const appStops = stops.filter((s) => s.label !== 'NEXTJS-PORTAL'); const need = ['Cek Pesanan Kustom', 'Jelajahi Katalog']; const reach = need.map((n) => labels.some((l) => l.includes(n)));
  const search = stops.some((s) => s.tag === 'INPUT'); const tabs = ['Home', 'Katalog', 'Layanan'].map((n) => labels.includes(n)); const plus = stops.filter((s) => s.icon).length; const noRing = appStops.filter((s) => !s.ring && s.tag !== 'INPUT').length;
  return { ok: reach.every(Boolean) && search && tabs.every(Boolean) && plus >= 3 && noRing === 0, actual: `${stops.length} fokus unik dari 45 Tab; Cek Pesanan Kustom/Jelajahi Katalog terjangkau: ${reach.join('/')}; kolom cari: ${search}; tab Home/Katalog/Layanan: ${tabs.join('/')}; tombol ikon (+) terjangkau: ${plus}; fokus tanpa indikator terlihat: ${noRing} (kolom cari memakai perubahan warna border kontainer, terlihat pada ACC-03_fokus-cari.png; elemen NEXTJS-PORTAL milik alat dev Next dikecualikan)`, shot: await shot(p, 'ACC-03') };
}, { viewport: DESKTOP });
tc('ACC-04', async (p) => {
  const out = [];
  for (const [name, act] of [['beranda', async () => {}], ['katalog', async () => { await clickText(p, 'Katalog'); await sleep(700); }]]) { await openPage(p); await act(); const v = await runAxe(p); out.push([name, v]); }
  const contrast = out.flatMap(([n, v]) => v.filter((x) => x.id === 'color-contrast').map((x) => `${n}: ${x.n} elemen (${x.impact})`)); const all = out.map(([n, v]) => `${n}: ${v.map((x) => x.id + '×' + x.n).join(', ') || 'tidak ada pelanggaran'}`);
  fs.writeFileSync('./evidence/ACC-04_axe.txt', JSON.stringify(out, null, 1));
  return { ok: contrast.length === 0, actual: `axe-core (WCAG 2 A/AA) kontras warna: ${contrast.join('; ') || 'tidak ada pelanggaran'}; seluruh pelanggaran -> ${all.join(' | ')}`, shot: await shot(p, 'ACC-04') };
});
tc('ACC-05', async (p) => {
  await openPage(p); const r = await p.evaluate(() => { const bs = [...document.querySelectorAll('button')].filter((b) => b.offsetParent && !(b.innerText || '').trim()); return bs.map((b) => { const r = b.getBoundingClientRect(); return { name: b.getAttribute('aria-label') || b.getAttribute('title') || null, w: Math.round(r.width), h: Math.round(r.height) }; }); });
  const noName = r.filter((x) => !x.name).length; const small = r.filter((x) => x.w < 44 || x.h < 44).length;
  return { ok: noName === 0 && small === 0, actual: `${r.length} tombol ikon di beranda; tanpa nama aksesibel (aria-label): ${noName}; ukuran < 44x44 px: ${small} (ukuran: ${r.map((x) => x.w + 'x' + x.h).join(', ')})`, shot: await shot(p, 'ACC-05') };
});

// ---------------- KONTEN ----------------
tc('CNT-03', async (p) => {
  const texts = {}; await openPage(p); texts.beranda = await bodyText(p); await clickText(p, 'Katalog'); await sleep(700); texts.katalog = await bodyText(p); await clickText(p, 'Layanan'); await sleep(900); texts.layanan = await bodyText(p);
  fs.writeFileSync('./evidence/CNT-03_teks.json', JSON.stringify(texts, null, 1));
  return { status: 'Not Run', actual: 'teks disimpan untuk ditinjau', shot: '' };
});
tc('CNT-04', async (p) => {
  const found = {}; await openPage(p); const home = await bodyText(p); await clickText(p, 'Layanan'); await sleep(900); const lay = await bodyText(p); await clickText(p, 'Home'); await sleep(500); await clickText(p, 'Katalog'); await sleep(600); await clickProduct(p, 'Template Excel UMKM'); await sleep(900); const det = await bodyText(p);
  const all = home + ' ' + lay + ' ' + det;
  for (const k of ['Garansi', 'Syarat', 'Privasi', 'Kebijakan', 'Refund', 'Pengembalian', 'Telegram', 'Email']) found[k] = all.includes(k);
  const detTabs = det.includes('Jaminan Garansi');
  return { ok: found.Garansi && (found.Syarat || found.Kebijakan) && found.Privasi, actual: `penjelasan garansi (tab Jaminan Garansi di detail: ${detTabs}; teks Garansi: ${found.Garansi}); Syarat dan Ketentuan: ${found.Syarat}; Kebijakan/Privasi: ${found.Privasi}; kontak lain (Telegram/Email): ${found.Telegram}/${found.Email}`, shot: await shot(p, 'CNT-04') };
});
tc('CNT-05', async (p) => {
  const bad = []; let total = 0;
  const scan = async (label) => { const t = await bodyText(p); for (const m of t.matchAll(/Rp\s?[\d.,]+/g)) { total++; if (!/^Rp\d{1,3}(\.\d{3})*$/.test(m[0])) bad.push(label + ':' + m[0]); } };
  await openPage(p); await scan('beranda'); await clickText(p, 'Katalog'); await sleep(600); await scan('katalog'); await addProduct(p, 0); await addProduct(p, 1); await openCart(p); await scan('keranjang'); await goCheckout(p); await scan('checkout');
  return { ok: bad.length === 0 && total > 0, actual: `${total} nilai harga diperiksa (beranda, katalog, keranjang, checkout); format tidak seragam: ${bad.length}${bad.length ? ' (' + bad.slice(0, 3).join(', ') + ')' : ''}`, shot: await shot(p, 'CNT-05') };
});
