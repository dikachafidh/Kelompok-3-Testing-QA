import fs from 'node:fs';
import { launch, newPage, MOBILE, DESKTOP } from './lib.mjs';
const only = (process.env.ONLY || '').split(',').filter(Boolean);
const files = (process.env.FILES || 'tc-batch1.mjs').split(',');
const resFile = './results.json';
const results = fs.existsSync(resFile) ? JSON.parse(fs.readFileSync(resFile, 'utf8')) : {};
for (const f of files) {
  const { TCS } = await import('./' + f);
  for (const t of TCS) {
    if (only.length && !only.some((o) => t.id.startsWith(o))) continue;
    const browser = await launch();
    const p = await newPage(browser, t.viewport || MOBILE);
    const t0 = Date.now(); let r;
    try { const out = await t.fn(p); r = { id: t.id, status: out.status || (out.ok ? 'Pass' : 'Fail'), actual: out.actual, evidence: out.shot || '', errs: p.__errs.slice(0, 3) }; }
    catch (e) { r = { id: t.id, status: 'ERROR', actual: 'galat skrip: ' + String(e.message).slice(0, 160), evidence: '' }; try { await p.screenshot({ path: `./evidence/${t.id}_error.png` }); } catch {} }
    r.ms = Date.now() - t0; results[t.id] = r;
    console.log(`${r.status.padEnd(5)} ${t.id}  ${r.actual}`);
    await browser.close();
    fs.writeFileSync(resFile, JSON.stringify(results, null, 1));
  }
}
fs.writeFileSync(resFile, JSON.stringify(results, null, 1));
