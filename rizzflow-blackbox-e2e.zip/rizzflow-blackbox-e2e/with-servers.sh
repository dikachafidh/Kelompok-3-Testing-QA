#!/bin/bash
# Menjalankan Supabase palsu + RizzFlow (next dev), menjalankan perintah $@, lalu mematikan server.
# APP_DIR = folder proyek RizzFlow (default ../RizzFlow-main) yang sudah npm install dan punya .env.local
E2E_DIR="$(pwd)"; APP_DIR="${APP_DIR:-../RizzFlow-main}"
node fake-supabase.mjs > /tmp/fake-supa.log 2>&1 & SP=$!
(cd "$APP_DIR" && npx next dev -p 3000 > /tmp/next-dev.log 2>&1) & NP=$!
for i in $(seq 1 60); do curl -s -m 2 -o /dev/null http://localhost:3000/ && break; sleep 2; done
cd "$E2E_DIR"; "$@"; RC=$?
kill $NP $SP 2>/dev/null; pkill -f "next dev" 2>/dev/null; pkill -f next-server 2>/dev/null
exit $RC
