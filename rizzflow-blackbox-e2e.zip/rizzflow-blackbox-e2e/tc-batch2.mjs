import { BASE, KNOWN, sleep, MOBILE, DESKTOP, openPage, bodyText, titles, clickText, clickProduct, detailOpen, iconButtons, addProduct, openCart, fill, searchProduct, goCheckout, shot, runAxe } from './lib.mjs';
export const TCS = [];
const tc = (id, fn, opts = {}) => TCS.push({ id, fn, ...opts });
const LAY = 'Halaman Status, Estimasi & Tagihan Kustom';
const has = async (p, s) => (await bodyText(p)).includes(s);
const orderCount = async () => (await (await fetch('http://127.0.0.1:54321/rest/v1/orders')).json()).length;
const cartTotal = async (p) => { const m = /Total Pembayaran \| (Rp[\d.]+)/.exec(await bodyText(p)); return m ? m[1] : null; };
const trash = (p) => p.evaluate(() => { const b = [...document.querySelectorAll('button')].filter((x) => x.offsetParent && x.querySelector('svg[class*="trash"]')); if (b.length) { b[0].click(); return true; } return false; });
const EMAIL = 'input[placeholder^="Contoh: nama@email.com"]';
const toCheckout = async (p, idxs = [0]) => { await openPage(p); for (const i of idxs) await addProduct(p, i); await openCart(p); await goCheckout(p); };
const submitCheckout = async (p) => { await clickText(p, 'Lanjut Pembayaran QRIS', false); await sleep(1800); };

// ---------------- KERANJANG & CHECKOUT ----------------
tc('CRT-01', async (p) => { await openPage(p); const before = await has(p, 'Keranjang Belanja'); await addProduct(p, 0); const t = await bodyText(p); const ok = !before && /1 \| Keranjang Belanja/.test(t) && t.includes('Rp5.000'); return { ok, actual: `sebelum tambah: indikator keranjang tampil=${before}; sesudah (+): ${ok ? 'indikator "1 Keranjang Belanja" dengan Rp5.000' : 'indikator tidak sesuai'}`, shot: await shot(p, 'CRT-01') }; });
tc('CRT-02', async (p) => { await openPage(p); for (let i = 0; i < 3; i++) await addProduct(p, 0); await openCart(p); const t = await bodyText(p); const tot = await cartTotal(p); const m = /Keranjang Belanja \((\d+)\)/.exec(t); const qty = await p.evaluate(() => { const sp = [...document.querySelectorAll('span')].filter((s) => /^\d+$/.test(s.innerText.trim()) && s.className.includes('text-center')); return sp.map((s) => s.innerText.trim()); }); return { ok: tot === 'Rp15.000' || !!m, actual: `tambah produk Rp5.000 tiga kali -> jumlah item di keranjang: ${qty.join(',') || '-'}; label: ${m ? m[0] : '-'}; total: ${tot}`, shot: await shot(p, 'CRT-02') }; });
tc('CRT-03', async (p) => { await openPage(p); await addProduct(p, 0); await addProduct(p, 1); await openCart(p); const tot = await cartTotal(p); const t = await bodyText(p); const ok = tot === 'Rp24.000' && t.includes('Rp5.000') && t.includes('Rp19.000'); return { ok, actual: `total keranjang Rp5.000 + Rp19.000 = ${tot}`, shot: await shot(p, 'CRT-03') }; });
tc('CRT-04', async (p) => { await openPage(p); await addProduct(p, 0); await addProduct(p, 1); await openCart(p); const d1 = await trash(p); await sleep(600); const tot1 = await cartTotal(p); const d2 = await trash(p); await sleep(700); const t = await bodyText(p); const kosong = /Keranjang masih kosong/.test(t); return { ok: d1 && tot1 !== 'Rp24.000' && kosong, actual: `hapus item 1: ${d1}, total jadi ${tot1}; hapus semua: ${d2}, pesan "Keranjang masih kosong": ${kosong}`, shot: await shot(p, 'CRT-04') }; });
tc('CRT-05', async (p) => { await openPage(p); await addProduct(p, 0); await p.reload({ waitUntil: 'networkidle2' }); await sleep(800); const t = await bodyText(p); const ok = /1 \| Keranjang Belanja/.test(t); await p.goto('about:blank'); await openPage(p); const t2 = await bodyText(p); return { ok: ok && /1 \| Keranjang Belanja/.test(t2), actual: `setelah F5: indikator keranjang ${ok ? 'tetap 1' : 'hilang'}; setelah menutup dan membuka ulang halaman (sesi sama): ${/1 \| Keranjang Belanja/.test(t2) ? 'tetap 1' : 'hilang'}`, shot: await shot(p, 'CRT-05') }; });
tc('CRT-06', async (p) => { await openPage(p, '/checkout'); await sleep(1200); const t = await bodyText(p); const url = p.url(); const info = /kosong|belum ada|Kembali ke Toko/i.test(t); const btn = await p.evaluate(() => [...document.querySelectorAll('button')].filter((b) => b.offsetParent && /Lanjut Pembayaran/.test(b.innerText)).map((b) => b.disabled)); return { ok: info && !btn.some((d) => d === false), actual: `buka /checkout dengan keranjang kosong -> URL ${url}; pesan/navigasi tersedia: ${info}; tombol bayar aktif: ${btn.some((d) => d === false)}; teks: ${t.slice(0, 120)}`, shot: await shot(p, 'CRT-06') }; });
tc('CRT-07', async (p) => {
  const log = [];
  const tryEmail = async (val) => { await toCheckout(p, [0]); const before = await bodyText(p); await fill(p, EMAIL, val); const n0 = await orderCount(); await submitCheckout(p); const after = await bodyText(p); const n1 = await orderCount(); const A = new Set(before.split(' | ')); const added = after.split(' | ').filter((x) => !A.has(x) && /email|@|domain|akhiran|spasi/i.test(x)).join(' ').slice(0, 110); return { err: added || null, created: n1 - n0 }; };
  const a = await tryEmail(''); log.push(`kosong -> "${a.err}", pesanan dibuat: ${a.created}`);
  const b2 = await tryEmail('abc'); log.push(`"abc" -> "${b2.err}", pesanan dibuat: ${b2.created}`);
  const c = await tryEmail(' a@b.co '); log.push(`" a@b.co " -> ${c.created ? 'diterima (spasi di tepi dipangkas)' : c.err}, pesanan dibuat: ${c.created}`);
  const longEmail = 'a'.repeat(240) + '@gmail.com';
  const d = await tryEmail(longEmail); log.push(`email ${longEmail.length} karakter -> ${d.created ? 'DITERIMA tanpa batas panjang' : d.err}, pesanan dibuat: ${d.created}`);
  const ok = !!a.err && !a.created && !!b2.err && !b2.created && c.created === 1 && !d.created;
  return { ok, actual: log.join('; '), shot: await shot(p, 'CRT-07') };
});
tc('CRT-08', async (p) => {
  await toCheckout(p, [0]); await fill(p, EMAIL, 'penguji@gmail.com'); const n0 = await orderCount(); await submitCheckout(p); await sleep(1200);
  const t = await bodyText(p); const hasQR = await p.evaluate(() => [...document.querySelectorAll('canvas,svg')].some((e) => e.getBoundingClientRect().width > 150 && e.getBoundingClientRect().height > 150));
  const nominal = t.includes('Rp5.000'); const n1 = await orderCount();
  return { ok: hasQR && nominal && n1 - n0 === 1, actual: `pesanan baru: ${n1 - n0}; kode QR tampil: ${hasQR}; nominal Rp5.000 tampil: ${nominal}; teks: ${t.slice(0, 150)}`, shot: await shot(p, 'CRT-08') };
});
tc('CRT-09', async (p) => {
  await toCheckout(p, [0]); await fill(p, EMAIL, 'penguji@gmail.com'); await submitCheckout(p); await sleep(1000); const n1 = await orderCount();
  await p.reload({ waitUntil: 'networkidle2' }); await sleep(1200); const n2 = await orderCount(); const afterReload = (await bodyText(p)).slice(0, 140);
  await p.goBack().catch(() => null); await sleep(800); const n3 = await orderCount();
  return { ok: n2 === n1 && n3 === n1, actual: `pesanan setelah bayar-tampil: ${n1}; setelah muat ulang: ${n2}; setelah Back: ${n3}; tampilan setelah muat ulang: "${afterReload}"`, shot: await shot(p, 'CRT-09') };
});
tc('CRT-10', async () => ({ status: 'Blocked', actual: 'Tidak dijalankan: pengiriman email dan konfirmasi pembayaran memerlukan SMTP dan pembeli uji pada situs live; di instans lokal email tidak terkonfigurasi.', shot: '' }));

// ---------------- LAYANAN KUSTOM ----------------
const goLayanan = async (p) => { await openPage(p); await clickText(p, 'Layanan'); await sleep(900); };
const CODE = 'input[placeholder^="Ketik Kode Pesanan"]';
tc('SVC-01', async (p) => { await goLayanan(p); const t = await bodyText(p); const items = ['Pembuatan Website Sederhana', 'Template Excel & Spreadsheet', 'Slide Presentasi PPT & Dokumen', 'Sistem Workspace Notion & Tools AI'].map((x) => t.includes(x)); return { ok: items.every(Boolean), actual: `empat layanan tampil: ${items.join('/')}`, shot: await shot(p, 'SVC-01') }; });
tc('SVC-02', async (p) => { await openPage(p); await clickText(p, 'Pesan / Cek Kode Kustom'); await sleep(900); const ok = (await has(p, LAY)) && !!(await p.$(CODE)); return { ok, actual: `form cek kode terbuka: ${ok}`, shot: await shot(p, 'SVC-02') }; });
const cekKode = async (p, val) => { const before = await bodyText(p); await fill(p, CODE, val); const dis = await p.evaluate(() => { const x = [...document.querySelectorAll('button')].find((e) => e.innerText.includes('Buka Status')); return x ? x.disabled : null; }); if (!dis) { await clickText(p, 'Buka Status & Tagihan'); await sleep(1800); } const after = await bodyText(p); const A = new Set(before.split(' | ')); const added = after.split(' | ').filter((x) => !A.has(x)).join(' ').slice(0, 140); const m = /tidak ditemukan/i.test(added) ? 'tidak ditemukan' : null; return { msg: m, disabled: dis, added }; };
tc('SVC-03', async (p) => { await goLayanan(p); const r = await cekKode(p, 'ABC-0000'); const realErrs = p.__errs.filter((e) => !e.includes('Failed to load resource')); return { ok: r.msg === 'tidak ditemukan' && realErrs.length === 0, actual: `kode ABC-0000 -> pesan: "${r.added}"; galat konsol selain status 404 yang wajar: ${realErrs.length}`, shot: await shot(p, 'SVC-03') }; });
tc('SVC-04', async (p) => { await goLayanan(p); const r = await cekKode(p, ''); return { ok: r.disabled === true, actual: `kode kosong -> tombol "Buka Status & Tagihan" dinonaktifkan: ${r.disabled}; tidak ada permintaan ke server`, shot: await shot(p, 'SVC-04') }; });
tc('SVC-05', async (p) => { const out = []; for (const v of [' kode ', 'KODE', 'kode']) { await goLayanan(p); out.push(await cekKode(p, v)); } return { ok: out.every((x) => x.msg === 'tidak ditemukan'), actual: out.map((x, i) => `${JSON.stringify([' kode ', 'KODE', 'kode'][i])} -> "${x.added.slice(0, 62)}"`).join('; '), shot: await shot(p, 'SVC-05') }; });
tc('SVC-06', async (p) => {
  await goLayanan(p); const before = p.__reqs.length;
  const clicked = await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.offsetParent && x.innerText.trim().startsWith('Buat Pesanan Kustom')); if (b) { b.scrollIntoView(); b.click(); return true; } return false; });
  await sleep(1200); const posts = p.__reqs.slice(before).filter((r) => r.startsWith('POST') && r.includes('/api/'));
  const invalid = await p.evaluate(() => [...document.querySelectorAll('input,textarea')].filter((i) => i.offsetParent && i.required && !i.checkValidity()).length);
  const t = await bodyText(p); const msg = /wajib|isi|lengkap|tidak boleh kosong/i.test(t);
  return { ok: clicked && posts.length === 0 && (invalid > 0 || msg), actual: `tombol kirim diklik tanpa isian: ${clicked}; kolom wajib tidak valid (native): ${invalid}; pesan validasi di halaman: ${msg}; permintaan POST ke API: ${posts.length}`, shot: await shot(p, 'SVC-06') };
});

// ---------------- RELIABILITAS & KEAMANAN ----------------
tc('REL-01', async (p) => { const res = await p.goto(BASE + '/halaman-tidak-ada', { waitUntil: 'networkidle2' }); await sleep(600); const t = await bodyText(p); const toHome = await p.evaluate(() => [...document.querySelectorAll('a,button')].some((e) => /beranda|home|kembali|toko/i.test(e.innerText))); return { ok: res.status() === 404 && /404|tidak ditemukan|tidak tersedia/i.test(t) && toHome, actual: `status HTTP ${res.status()}; teks: "${t.slice(0, 100)}"; ada tautan kembali: ${toHome}`, shot: await shot(p, 'REL-01') }; });
tc('REL-02', async (p) => {
  await openPage(p); await clickText(p, 'Katalog'); await sleep(700); await p.setOfflineMode(true); await searchProduct(p, 'rumus'); const a = await titles(p); await clickText(p, 'Beranda', false).catch(() => null);
  await addProduct(p, 0).catch(() => null); await p.setOfflineMode(false); await sleep(800); const t = await bodyText(p); const crashed = /Application error|Unhandled/i.test(t);
  return { ok: !crashed && p.__errs.filter((e) => e.startsWith('pageerror')).length === 0, actual: `saat offline: pencarian "rumus" -> ${a.length} hasil; tidak ada layar galat aplikasi: ${!crashed}; pageerror: ${p.__errs.filter((e) => e.startsWith('pageerror')).length}; setelah online: halaman tetap berfungsi`, shot: await shot(p, 'REL-02') };
});
tc('SEC-01', async () => ({ status: 'Blocked', actual: 'Tidak dapat diuji pada instans lokal (http://localhost); pengalihan HTTP ke HTTPS ditangani hosting live (Vercel).', shot: '' }));
tc('SEC-02', async () => ({ status: 'Blocked', actual: 'Tidak relevan pada instans lokal (seluruh sumber lewat http); perlu diuji pada situs live di browser.', shot: '' }));
tc('SEC-03', async (p) => {
  await openPage(p); await searchProduct(p, '<b>uji</b> \' " &'); const bTag = await p.evaluate(() => [...document.querySelectorAll('b')].filter((e) => e.innerText === 'uji' && !e.closest('input')).length);
  await clickText(p, 'Layanan'); await sleep(800); await fill(p, CODE, '<b>uji</b> \' " &'); await clickText(p, 'Buka Status & Tagihan'); await sleep(1200);
  const bTag2 = await p.evaluate(() => [...document.querySelectorAll('b')].filter((e) => e.innerText === 'uji').length);
  return { ok: bTag === 0 && bTag2 === 0 && p.__dialogs === 0 && p.__errs.filter((e) => e.startsWith('pageerror')).length === 0, actual: `elemen <b> hasil render dari input: pencarian=${bTag}, cek kode=${bTag2}; dialog muncul: ${p.__dialogs}; pageerror: ${p.__errs.filter((e) => e.startsWith('pageerror')).length}`, shot: await shot(p, 'SEC-03') };
});
tc('SEC-04', async () => ({ status: 'Blocked', actual: 'Tidak dijalankan: memerlukan kode pesanan kustom milik sendiri yang dibuat admin di sistem asli; data pesanan kustom tidak ada di instans lokal.', shot: '' }));
