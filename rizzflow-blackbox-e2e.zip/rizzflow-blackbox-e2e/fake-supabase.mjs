// Server Supabase palsu minimal (PostgREST + storage) untuk menjalankan RizzFlow secara lokal.
// Data seed meniru pengamatan situs live pada 18 November 2026 (3 produk, 4 kategori).
import http from 'node:http';
import crypto from 'node:crypto';

const uuid = () => crypto.randomUUID();
const now = () => new Date().toISOString();
const day = (d) => new Date(Date.now() + d * 86400000).toISOString();

const cat = {
  premium: { id: uuid(), name: 'Akun Premium', slug: 'akun-premium', created_at: day(-30) },
  ebook: { id: uuid(), name: 'E-Book', slug: 'e-book', created_at: day(-30) },
  excel: { id: uuid(), name: 'Template Excel', slug: 'template-excel', created_at: day(-30) },
  ppt: { id: uuid(), name: 'Template PPT', slug: 'template-ppt', created_at: day(-30) },
};
const db = {
  store_settings: [{ id: 1, store_name: 'RizzFlow', banner_description: 'Solusi Produk Digital Instan, Praktis, dan Berkualitas.', support_contact: 'rizzflow55@gmail.com', updated_at: now() }],
  categories: Object.values(cat),
  products: [
    { id: 'prod-kata-sambutan', category_id: cat.ebook.id, title: '7 Jurus Sakti Kata Sambutan - Siap Pakai Untuk Segala Acara !', description: 'Ebook ini berisi 7 jurus sakti kata sambutan untuk kamu yang ingin tampil dengan profesional dan berkualitas', price: 5000, thumbnail_url: 'http://127.0.0.1:54321/img/kata-sambutan.svg', file_path: 'kata-sambutan.pdf', badge: 'Baru', is_active: true, created_at: day(-1) },
    { id: 'prod-rumus-mtk', category_id: cat.ebook.id, title: 'Kumpulan Rumus Matematika SMA', description: 'Ebook ini berisi kumpulan rumus-rumus matematika secara lengkap', price: 19000, thumbnail_url: 'http://127.0.0.1:54321/img/rumus-mtk.svg', file_path: 'rumus-mtk.pdf', badge: null, is_active: true, created_at: day(-2) },
    { id: 'prod-excel-umkm', category_id: cat.excel.id, title: 'Template Excel UMKM', description: 'Template untuk UMKM yang berfungsi sebagai penghitung harga jual dan keuntungan dengan cepat dan mudah', price: 29000, thumbnail_url: 'http://127.0.0.1:54321/img/excel-umkm.svg', file_path: 'excel-umkm.xlsx', badge: 'Terlaris', is_active: true, created_at: day(-3) },
  ],
  // Kode promo di bawah ini dibuat HANYA untuk uji lokal (tidak ada di situs live).
  promo_codes: [
    { id: uuid(), code: 'HEMAT20', discount_percent: 20, max_discount_amount: 15000, starts_at: day(-10), expires_at: day(30), is_active: true, created_at: now() },
    { id: uuid(), code: 'LAWAS10', discount_percent: 10, max_discount_amount: 5000, starts_at: day(-60), expires_at: day(-30), is_active: true, created_at: now() },
  ],
  orders: [],
  order_items: [],
};
export const state = db;

const COLORS = { 'kata-sambutan': '#6d28d9', 'rumus-mtk': '#0e7490', 'excel-umkm': '#15803d' };
const svg = (name) => `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600"><rect width="600" height="600" fill="${COLORS[name] || '#444'}"/><text x="300" y="310" font-size="42" fill="#fff" text-anchor="middle" font-family="sans-serif">${name}</text></svg>`;

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Range');
}
function parseFilters(sp) {
  const f = [];
  for (const [k, v] of sp.entries()) {
    if (['select', 'order', 'limit', 'offset', 'on_conflict', 'columns'].includes(k)) continue;
    const m = /^(eq|neq|in|gt|gte|lt|lte|is|ilike)\.(.*)$/.exec(v);
    if (m) f.push([k, m[1], m[2]]);
  }
  return f;
}
const coerce = (row, col, val) => {
  const cur = row[col];
  if (typeof cur === 'boolean') return val === 'true';
  if (typeof cur === 'number') return Number(val);
  return val;
};
function matches(row, filters) {
  return filters.every(([col, op, val]) => {
    if (op === 'in') {
      const list = val.replace(/^\(|\)$/g, '').split(',').map((s) => s.replace(/^"|"$/g, ''));
      return list.includes(String(row[col]));
    }
    if (op === 'is') return String(row[col]) === val || (val === 'null' && row[col] == null);
    if (op === 'ilike') return String(row[col] ?? '').toLowerCase() === val.toLowerCase().replace(/%/g, '');
    const c = coerce(row, col, val);
    if (op === 'eq') return row[col] === c || String(row[col]) === val;
    if (op === 'neq') return !(row[col] === c || String(row[col]) === val);
    if (op === 'gt') return row[col] > c; if (op === 'gte') return row[col] >= c;
    if (op === 'lt') return row[col] < c; if (op === 'lte') return row[col] <= c;
    return true;
  });
}
function embed(table, row, select) {
  const out = { ...row };
  if (select && /categories\(\*\)/.test(select) && table === 'products') out.categories = db.categories.find((c) => c.id === row.category_id) || null;
  if (select && /order_items\(\*\)/.test(select) && table === 'orders') out.order_items = db.order_items.filter((i) => i.order_id === row.id);
  return out;
}
function readBody(req) {
  return new Promise((r) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => r(b)); });
}

export function start(port = 54321) {
  const server = http.createServer(async (req, res) => {
    cors(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    const url = new URL(req.url, `http://127.0.0.1:${port}`);
    const p = url.pathname;
    const wantsObject = (req.headers.accept || '').includes('vnd.pgrst.object');
    const json = (code, body, extra = {}) => { res.writeHead(code, { 'Content-Type': 'application/json', ...extra }); res.end(JSON.stringify(body)); };

    const img = /^\/img\/(.+)\.svg$/.exec(p);
    if (img) { res.writeHead(200, { 'Content-Type': 'image/svg+xml' }); return res.end(svg(img[1])); }

    if (p.startsWith('/storage/v1/')) {
      if (req.method === 'GET') return json(404, { statusCode: '404', error: 'not_found', message: 'Object not found' });
      if (p.includes('/object/list/')) return json(200, []);
      await readBody(req);
      return json(200, { Key: 'ok', Id: uuid() });
    }
    if (p.startsWith('/auth/v1/')) { await readBody(req); return json(400, { error: 'invalid_grant', error_description: 'Invalid login credentials' }); }

    const m = /^\/rest\/v1\/([a-z_]+)$/.exec(p);
    if (!m) return json(404, { message: 'not found' });
    const table = m[1];
    if (!db[table]) return json(404, { code: '42P01', message: `relation ${table} does not exist` });
    const filters = parseFilters(url.searchParams);
    const select = url.searchParams.get('select');

    if (req.method === 'GET' || req.method === 'HEAD') {
      let rows = db[table].filter((r) => matches(r, filters));
      const order = url.searchParams.get('order');
      if (order) {
        const [col, dir] = order.split('.');
        rows = [...rows].sort((a, b) => (a[col] > b[col] ? 1 : a[col] < b[col] ? -1 : 0) * (dir === 'desc' ? -1 : 1));
      }
      const lim = url.searchParams.get('limit'); if (lim) rows = rows.slice(0, Number(lim));
      rows = rows.map((r) => embed(table, r, select));
      if (wantsObject) {
        if (!rows.length) return json(406, { code: 'PGRST116', details: 'The result contains 0 rows', message: 'JSON object requested, multiple (or no) rows returned' });
        return json(200, rows[0]);
      }
      return json(200, rows, { 'Content-Range': `0-${Math.max(rows.length - 1, 0)}/${rows.length}` });
    }
    if (req.method === 'POST') {
      const body = JSON.parse((await readBody(req)) || '{}');
      const arr = Array.isArray(body) ? body : [body];
      const created = arr.map((r) => { const row = { id: uuid(), created_at: now(), ...r }; db[table].push(row); return row; });
      const out = wantsObject ? created[0] : created;
      return json(201, out);
    }
    if (req.method === 'PATCH') {
      const patch = JSON.parse((await readBody(req)) || '{}');
      const rows = db[table].filter((r) => matches(r, filters));
      rows.forEach((r) => Object.assign(r, patch));
      return json(200, wantsObject ? (rows[0] || null) : rows);
    }
    if (req.method === 'DELETE') { db[table] = db[table].filter((r) => !matches(r, filters)); return json(204, {}); }
    json(405, { message: 'method not allowed' });
  });
  return new Promise((r) => server.listen(port, '127.0.0.1', () => r(server)));
}

if (process.argv[1] && process.argv[1].endsWith('fake-supabase.mjs')) {
  start().then(() => console.log('fake supabase: http://127.0.0.1:54321'));
}
