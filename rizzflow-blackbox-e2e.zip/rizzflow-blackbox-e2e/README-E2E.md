# Uji Black Box Otomatis (keyword-driven) — RizzFlow

Skrip Chromium (puppeteer-core) yang menjalankan test case black box pada instans LOKAL RizzFlow dengan Supabase palsu (data seed setara situs live) dan pembayaran DOKU mode simulasi. Tidak menyentuh situs live.

## Menjalankan ulang
1. Siapkan proyek RizzFlow di `../RizzFlow-main` (atau set `APP_DIR`), jalankan `npm install`, dan buat `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321
   NEXT_PUBLIC_SUPABASE_ANON_KEY=anon-test-key
   SUPABASE_SERVICE_ROLE_KEY=service-test-key
   DOKU_SIMULATION_MODE=true
   NEXT_PUBLIC_APP_URL=http://localhost:3000
   ```
   Opsional: tambahkan `devIndicators: false` pada `next.config.ts` (salinan lokal) agar indikator dev tidak muncul di screenshot.
2. Di folder ini: `npm install` (memasang puppeteer-core, @sparticuz/chromium, axe-core).
3. Jalankan (bash; Linux/macOS/WSL):
   ```bash
   ./with-servers.sh env FILES=tc-batch1.mjs,tc-batch2.mjs,tc-batch3.mjs node run.mjs
   ```
   Filter: `ONLY=NAV,SRC` untuk menjalankan sebagian. Hasil: `results.json` dan screenshot di `evidence/`.
4. Pada Windows tanpa WSL, ganti `executablePath` di `lib.mjs` dengan jalur Google Chrome milikmu.

## Hasil eksekusi awal (18-19 November 2026)
`results_final.json` memuat hasil 76 test case: 47 Pass, 8 Fail, 9 Blocked, 12 Not Run (usability dan performance belum dijalankan). Sebagian entri (CNT-01, CNT-02, CNT-03, PRD-03, PRF, USB) dicatat manual pada berkas JSON, bukan oleh skrip.

## Catatan
- Skrip ini awalnya dijalankan oleh asisten AI; jalankan ulang, pahami hasilnya, dan cantumkan penggunaan alat bantu AI sesuai aturan kampus.
- Kode sumber RizzFlow TIDAK disertakan di paket ini. Jangan unggah kode sumber orang lain ke repo publik.
