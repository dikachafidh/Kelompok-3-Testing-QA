import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import crypto from 'node:crypto';
import { newState, makeClient } from './helpers/fakeSupabase';

const h = vi.hoisted(() => ({
  state: null as any, makeClient: null as any,
  email: vi.fn(), notify: vi.fn(), build: vi.fn(), backup: vi.fn(),
}));
vi.mock('@/lib/supabase', () => ({
  getSupabaseAdmin: () => h.makeClient(h.state),
  buildProductDeliveryItems: h.build,
  sendAdminTelegramNotification: h.notify,
  getOrderItemsBackup: h.backup,
}));
vi.mock('@/lib/email', () => ({ sendProductDeliveryEmail: h.email }));

import { POST } from '@/app/api/webhooks/doku/route';

// Penghitung signature independen (mengikuti spesifikasi DOKU, bukan memanggil kode produksi)
function sign(secret: string, body: string, headers = { c: 'C', r: 'R', t: 'T' }) {
  const digest = crypto.createHash('sha256').update(body, 'utf8').digest('base64');
  const comp = `Client-Id:${headers.c}\nRequest-Id:${headers.r}\nRequest-Timestamp:${headers.t}\nRequest-Target:/api/webhooks/doku\nDigest:${digest}`;
  return 'HMACSHA256=' + crypto.createHmac('sha256', secret).update(comp, 'utf8').digest('base64');
}
async function hook(payload: any, sig: string | null, extra: Record<string, string> = {}) {
  const body = typeof payload === 'string' ? payload : JSON.stringify(payload);
  const headers: Record<string, string> = { 'Client-Id': 'C', 'Request-Id': 'R', 'Request-Timestamp': 'T', ...extra };
  if (sig !== null) headers['Signature'] = sig;
  const res: any = await POST(new Request('http://x/api/webhooks/doku', { method: 'POST', headers, body }));
  return { status: res.status as number, json: (await res.json()) as any };
}
const SECRET = 'test-secret';
const pending = (over: any = {}) => ({
  id: 'o1', invoice_number: 'INV-1', customer_email: 'pembeli@gmail.com', final_amount: 5000,
  payment_status: 'PENDING', order_items: [{ product_id: 'p1', product_title: 'E-Book', quantity: 1 }], ...over,
});
const success = (amount = 5000, inv = 'INV-1') => ({ order: { invoice_number: inv, amount }, transaction: { status: 'SUCCESS' } });

beforeEach(() => {
  vi.stubEnv('DOKU_SIMULATION_MODE', 'false'); vi.stubEnv('DOKU_SECRET_KEY', SECRET);
  h.makeClient = makeClient;
  h.state = newState({ products: [{ id: 'p1', title: 'E-Book', file_path: 'x.pdf', price: 5000 }], orders: [pending()] });
  Object.values(h).forEach((v: any) => v?.mockReset?.());
  h.build.mockResolvedValue([{ name: 'E-Book', url: 'https://link' }]);
  h.email.mockResolvedValue(undefined); h.notify.mockResolvedValue(undefined); h.backup.mockResolvedValue([]);
});
afterEach(() => vi.unstubAllEnvs());

describe('keamanan signature webhook', () => {
  it('signature salah: 401 dan pesanan tidak berubah', async () => {
    const r = await hook(success(), 'HMACSHA256=salah');
    expect(r.status).toBe(401); expect(h.state.orders[0].payment_status).toBe('PENDING');
  });
  it('tanpa header Signature: 401', async () => {
    expect((await hook(success(), null)).status).toBe(401);
  });
  it('secret key tidak diatur: semua permintaan ditolak (401)', async () => {
    vi.stubEnv('DOKU_SECRET_KEY', '');
    const body = JSON.stringify(success());
    expect((await hook(body, sign('', body))).status).toBe(401);
  });
  it('mode produksi: header SIMULATION_BYPASS TIDAK boleh melewati verifikasi', async () => {
    const r = await hook(success(), 'SIMULATION_BYPASS');
    expect(r.status).toBe(401); expect(h.email).not.toHaveBeenCalled();
  });
  it('mode simulasi: SIMULATION_BYPASS diterima (perilaku yang disengaja)', async () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'true');
    const r = await hook(success(), 'SIMULATION_BYPASS');
    expect(r.status).toBe(200); expect(h.state.orders[0].payment_status).toBe('PAID');
  });
  it('signature valid: diterima', async () => {
    const body = JSON.stringify(success());
    expect((await hook(body, sign(SECRET, body))).status).toBe(200);
  });
  it('body diubah setelah ditandatangani: 401', async () => {
    const body = JSON.stringify(success(5000));
    const sig = sign(SECRET, body);
    expect((await hook(JSON.stringify(success(1)), sig)).status).toBe(401);
  });
});

describe('alur pembayaran', () => {
  const run = async (payload: any) => { const b = JSON.stringify(payload); return hook(b, sign(SECRET, b)); };
  it('tanpa invoice_number: 400', async () => {
    expect((await run({ transaction: { status: 'SUCCESS' } })).status).toBe(400);
  });
  it('status bukan SUCCESS: diterima tanpa mengubah pesanan', async () => {
    const r = await run({ order: { invoice_number: 'INV-1' }, transaction: { status: 'FAILED' } });
    expect(r.json.received).toBe(true); expect(h.state.orders[0].payment_status).toBe('PENDING');
  });
  it('pesanan tidak ditemukan: 404', async () => {
    expect((await run(success(5000, 'INV-NOPE'))).status).toBe(404);
  });
  it('pesanan sudah PAID: idempoten, tidak kirim email lagi', async () => {
    h.state.orders = [pending({ payment_status: 'PAID' })];
    const r = await run(success());
    expect(r.json.message).toMatch(/already processed/); expect(h.email).not.toHaveBeenCalled();
  });
  it('sukses: pesanan jadi PAID, email terkirim sekali dengan tautan produk', async () => {
    const r = await run(success());
    expect(r.status).toBe(200); expect(h.state.orders[0].payment_status).toBe('PAID');
    expect(h.email).toHaveBeenCalledTimes(1);
    expect(h.email.mock.calls[0][0].files).toHaveLength(1);
  });
  it('item pesanan di DB kosong: memakai cadangan dari storage', async () => {
    h.state.orders = [pending({ order_items: [] })];
    h.backup.mockResolvedValue([{ product_id: 'p1', product_title: 'E-Book', quantity: 1 }]);
    await run(success());
    expect(h.email.mock.calls[0][0].files).toHaveLength(1);
  });
  it('email gagal terkirim: pesanan tetap PAID dan respons menandai peringatan', async () => {
    h.email.mockRejectedValue(new Error('SMTP down'));
    const r = await run(success());
    expect(h.state.orders[0].payment_status).toBe('PAID'); expect(r.json.email_status).toContain('GAGAL');
  });
  it('[TEMUAN] nominal pada webhook harus sama dengan final_amount pesanan', async () => {
    const r = await run(success(1)); // dibayar Rp1, tagihan Rp5.000
    expect(r.status).not.toBe(200);
    expect(h.state.orders[0].payment_status).not.toBe('PAID');
  });
  it('[TEMUAN] dua webhook bersamaan untuk invoice yang sama hanya boleh mengirim satu email', async () => {
    const b = JSON.stringify(success()); const sig = sign(SECRET, b);
    await Promise.all([hook(b, sig), hook(b, sig)]);
    expect(h.email).toHaveBeenCalledTimes(1);
  });
});
