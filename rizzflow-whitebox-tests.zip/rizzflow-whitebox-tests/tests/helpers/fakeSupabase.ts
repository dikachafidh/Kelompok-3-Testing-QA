// Supabase palsu berbasis memori untuk menguji logika route tanpa database nyata.
// Mendukung rantai pemanggilan seperti from().select().eq().maybeSingle() dan insert().select().single().
export interface FakeState {
  products: any[];
  promo: any | null;
  promoError: any | null;
  orders: any[];                // pesanan yang ada (untuk webhook / orders route)
  orderInsertError: any | null;
  itemsInsertError: any | null;
  inserts: { orders: any[]; order_items: any[] };
  updates: { orders: { patch: any; id: any }[] };
}

export function newState(over: Partial<FakeState> = {}): FakeState {
  return {
    products: [], promo: null, promoError: null, orders: [],
    orderInsertError: null, itemsInsertError: null,
    inserts: { orders: [], order_items: [] },
    updates: { orders: [] },
    ...over,
  };
}

export function makeClient(state: FakeState) {
  return {
    auth: { getUser: async () => ({ data: { user: null }, error: { message: 'no' } }) },
    from(table: string) {
      const q: any = { table, op: 'select', payload: null, filters: {} as Record<string, any> };
      const resolve = () => {
        if (table === 'products') return { data: state.products, error: null };
        if (table === 'promo_codes') return { data: state.promo, error: state.promoError };
        if (table === 'orders' && q.op === 'insert') {
          if (state.orderInsertError) return { data: null, error: state.orderInsertError };
          const row = { id: 'order-uuid-1', ...q.payload };
          state.inserts.orders.push(q.payload);
          return { data: row, error: null };
        }
        if (table === 'orders' && q.op === 'update') {
          state.updates.orders.push({ patch: q.payload, id: q.filters.id });
          const o = state.orders.find((x) => x.id === q.filters.id);
          if (o) Object.assign(o, q.payload);
          return { data: null, error: null };
        }
        if (table === 'orders') {
          const o = state.orders.find((x) => x.invoice_number === q.filters.invoice_number);
          return { data: o ? { ...o } : null, error: null };
        }
        if (table === 'order_items' && q.op === 'insert') {
          state.inserts.order_items.push(...(Array.isArray(q.payload) ? q.payload : [q.payload]));
          return { data: null, error: state.itemsInsertError };
        }
        return { data: null, error: null };
      };
      q.select = () => q;
      q.in = () => q;
      q.eq = (k: string, v: any) => { q.filters[k] = v; return q; };
      q.insert = (p: any) => { q.op = 'insert'; q.payload = p; return q; };
      q.update = (p: any) => { q.op = 'update'; q.payload = p; return q; };
      q.single = () => Promise.resolve(resolve());
      q.maybeSingle = () => Promise.resolve(resolve());
      q.then = (res: any, rej: any) => Promise.resolve(resolve()).then(res, rej);
      return q;
    },
  };
}
