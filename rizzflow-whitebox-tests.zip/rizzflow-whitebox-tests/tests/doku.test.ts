import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  calculatePromoDiscount,
  generateDokuSignature,
  verifyDokuWebhookSignature,
  createDokuQrisPayment,
} from '@/lib/doku';

const promo = (over: any = {}) => ({
  id: 'p1', code: 'HEMAT20', discount_percent: 20, max_discount_amount: 15000,
  starts_at: '2020-01-01T00:00:00Z', expires_at: '2099-01-01T00:00:00Z',
  is_active: true, created_at: '2020-01-01T00:00:00Z', ...over,
});

describe('calculatePromoDiscount (white box: seluruh cabang)', () => {
  it('menolak promo null', () => {
    const r = calculatePromoDiscount(100000, null);
    expect(r.valid).toBe(false); expect(r.discount_amount).toBe(0);
  });
  it('menolak promo nonaktif', () => {
    expect(calculatePromoDiscount(100000, promo({ is_active: false })).valid).toBe(false);
  });
  it('menolak promo yang belum aktif', () => {
    const r = calculatePromoDiscount(100000, promo({ starts_at: '2099-01-01T00:00:00Z', expires_at: '2100-01-01T00:00:00Z' }));
    expect(r.valid).toBe(false); expect(r.message).toMatch(/belum memasuki/);
  });
  it('menolak promo kedaluwarsa', () => {
    const r = calculatePromoDiscount(100000, promo({ expires_at: '2021-01-01T00:00:00Z' }));
    expect(r.valid).toBe(false); expect(r.message).toMatch(/habis/);
  });
  it('menghitung diskon persen tanpa menyentuh batas', () => {
    const r = calculatePromoDiscount(50000, promo({ discount_percent: 10, max_discount_amount: 100000 }));
    expect(r.valid).toBe(true); expect(r.discount_amount).toBe(5000);
  });
  it('membatasi diskon pada max_discount_amount', () => {
    expect(calculatePromoDiscount(100000, promo()).discount_amount).toBe(15000); // 20% = 20000 -> cap 15000
  });
  it('diskon 100% tidak melebihi subtotal', () => {
    const r = calculatePromoDiscount(5000, promo({ discount_percent: 100, max_discount_amount: 999999 }));
    expect(r.discount_amount).toBe(5000);
  });
  it('membulatkan ke bawah (floor) untuk nilai pecahan', () => {
    expect(calculatePromoDiscount(999, promo({ discount_percent: 10, max_discount_amount: 99999 })).discount_amount).toBe(99);
  });
  it('batas tepat: waktu sekarang di antara starts_at dan expires_at diterima', () => {
    const now = Date.now();
    const r = calculatePromoDiscount(10000, promo({ starts_at: new Date(now - 1000).toISOString(), expires_at: new Date(now + 60000).toISOString() }));
    expect(r.valid).toBe(true);
  });
  it('nilai batas: subtotal 0 menghasilkan diskon 0', () => {
    expect(calculatePromoDiscount(0, promo()).discount_amount).toBe(0);
  });
  it('[TEMUAN] max_discount_amount = 0 seharusnya berarti "tanpa batas" seperti pada route checkout', () => {
    // Checkout memperlakukan 0 sebagai tanpa batas; fungsi ini menjadikannya diskon 0.
    const r = calculatePromoDiscount(100000, promo({ discount_percent: 10, max_discount_amount: 0 }));
    expect(r.discount_amount).toBe(10000);
  });
});

describe('generateDokuSignature', () => {
  const base = {
    clientId: 'CLIENT123', requestId: 'REQ-1', requestTimestamp: '2026-11-15T10:00:00Z',
    requestTarget: '/checkout/v1/payment', bodyString: '{"a":1}', secretKey: 'secret',
  };
  it('cocok dengan vektor uji yang dihitung independen (Python/HMAC-SHA256)', () => {
    expect(generateDokuSignature(base)).toBe('HMACSHA256=brouiorz/Rm1+g/2K9RV6ZXoqwdPfDXEc8bewIcBRjQ=');
  });
  it('deterministik untuk input yang sama', () => {
    expect(generateDokuSignature(base)).toBe(generateDokuSignature({ ...base }));
  });
  it.each([
    ['bodyString', '{"a":2}'], ['secretKey', 'other'], ['requestId', 'REQ-2'], ['requestTimestamp', '2026-11-15T10:00:01Z'],
  ])('berubah jika %s berubah', (k, v) => {
    expect(generateDokuSignature({ ...base, [k]: v } as any)).not.toBe(generateDokuSignature(base));
  });
});

describe('verifyDokuWebhookSignature', () => {
  afterEach(() => vi.unstubAllEnvs());
  const args = (sig: string, body = '{"x":1}') => ({
    clientIdHeader: 'C', requestIdHeader: 'R', requestTimestampHeader: 'T',
    signatureHeader: sig, requestTarget: '/api/webhooks/doku', rawBody: body,
  });
  it('mode simulasi: selalu true (bypass)', () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'true');
    expect(verifyDokuWebhookSignature(args('apa-saja'))).toBe(true);
  });
  it('tanpa secret key: false', () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'false'); vi.stubEnv('DOKU_SECRET_KEY', '');
    expect(verifyDokuWebhookSignature(args('x'))).toBe(false);
  });
  it('signature valid: true; body diubah: false', () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'false'); vi.stubEnv('DOKU_SECRET_KEY', 'secret');
    const sig = generateDokuSignature({ clientId: 'C', requestId: 'R', requestTimestamp: 'T', requestTarget: '/api/webhooks/doku', bodyString: '{"x":1}', secretKey: 'secret' });
    expect(verifyDokuWebhookSignature(args(sig))).toBe(true);
    expect(verifyDokuWebhookSignature(args(sig, '{"x":2}'))).toBe(false);
  });
});

describe('createDokuQrisPayment', () => {
  beforeEach(() => vi.stubEnv('DOKU_SIMULATION_MODE', 'true'));
  afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); });

  it('mode simulasi: QR memuat nomor invoice dan kedaluwarsa ~60 menit', async () => {
    const t0 = Date.now();
    const r = await createDokuQrisPayment({ invoiceNumber: 'INV-1-123', amount: 5000, customerEmail: 'a@b.co' });
    expect(r.qris_string).toContain('INV-1-123');
    const diffMin = (new Date(r.expires_at).getTime() - t0) / 60000;
    expect(diffMin).toBeGreaterThan(59.9); expect(diffMin).toBeLessThan(60.1);
  });
  it('mode nyata: memakai qr_string dari DOKU', async () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'false');
    vi.stubGlobal('fetch', vi.fn(async () => ({ ok: true, json: async () => ({ response: { payment: { qr_string: 'QR-DARI-DOKU' } } }) })));
    const r = await createDokuQrisPayment({ invoiceNumber: 'INV-2', amount: 9000, customerEmail: 'a@b.co' });
    expect(r.qris_string).toBe('QR-DARI-DOKU');
  });
  it('mode nyata: HTTP error dari DOKU melempar galat', async () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'false');
    vi.stubGlobal('fetch', vi.fn(async () => ({ ok: false, text: async () => 'boom' })));
    await expect(createDokuQrisPayment({ invoiceNumber: 'INV-3', amount: 9000, customerEmail: 'a@b.co' })).rejects.toThrow(/Gagal membuat QRIS DOKU/);
  });
  it('[TEMUAN] respons DOKU tanpa qr_string/url tidak boleh diganti QR palsu', async () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'false');
    vi.stubGlobal('fetch', vi.fn(async () => ({ ok: true, json: async () => ({ response: { payment: {} } }) })));
    await expect(createDokuQrisPayment({ invoiceNumber: 'INV-4', amount: 9000, customerEmail: 'a@b.co' })).rejects.toThrow();
  });
});
