import { describe, it, expect, vi, beforeEach } from 'vitest';
import { newState, makeClient } from './helpers/fakeSupabase';

const h = vi.hoisted(() => ({ state: null as any, makeClient: null as any }));
vi.mock('@/lib/supabase', () => ({ getSupabaseAdmin: () => h.makeClient(h.state) }));

import { POST as validatePromo } from '@/app/api/promo/validate/route';
import { GET as getOrder } from '@/app/api/orders/[invoice]/route';

const promoRow = (over: any = {}) => ({
  id: 'x', code: 'HEMAT20', discount_percent: 20, max_discount_amount: 15000,
  starts_at: '2020-01-01T00:00:00Z', expires_at: '2099-01-01T00:00:00Z', is_active: true, ...over,
});
async function validate(body: any) {
  const res: any = await validatePromo(new Request('http://x/api/promo/validate', { method: 'POST', body: JSON.stringify(body) }));
  return { status: res.status as number, json: (await res.json()) as any };
}
async function order(invoice: string) {
  const res: any = await getOrder(new Request('http://x'), { params: Promise.resolve({ invoice }) });
  return { status: res.status as number, json: (await res.json()) as any };
}

beforeEach(() => { h.makeClient = makeClient; h.state = newState(); });

describe('POST /api/promo/validate', () => {
  it('menolak kode kosong (400)', async () => {
    const r = await validate({ code: '   ', subtotal: 10000 });
    expect(r.status).toBe(400); expect(r.json.valid).toBe(false);
  });
  it.each([[0], [-1], [undefined]])('menolak subtotal %s (400)', async (s) => {
    expect((await validate({ code: 'HEMAT20', subtotal: s })).status).toBe(400);
  });
  it('[TEMUAN] subtotal bukan angka ("abc") seharusnya ditolak, bukan menghasilkan "RpNaN"', async () => {
    h.state.promo = promoRow();
    const r = await validate({ code: 'HEMAT20', subtotal: 'abc' });
    expect(r.status).toBe(400);
  });
  it('kode tidak ditemukan (400)', async () => {
    h.state.promo = null;
    const r = await validate({ code: 'NOPE', subtotal: 10000 });
    expect(r.status).toBe(400); expect(r.json.valid).toBe(false);
  });
  it('kode valid (huruf kecil dinormalkan) mengembalikan potongan', async () => {
    h.state.promo = promoRow();
    const r = await validate({ code: 'hemat20', subtotal: 50000 });
    expect(r.status).toBe(200); expect(r.json.discount_amount).toBe(10000); expect(r.json.promo_code).toBe('HEMAT20');
  });
  it('kesalahan database menghasilkan 500', async () => {
    h.state.promoError = { message: 'db' };
    expect((await validate({ code: 'HEMAT20', subtotal: 1000 })).status).toBe(500);
  });
});

describe('GET /api/orders/[invoice]', () => {
  const base = (over: any = {}) => ({
    id: 'o1', invoice_number: 'INV-1', customer_email: 'pembeli@gmail.com', final_amount: 5000,
    payment_status: 'PENDING', qris_string: 'QR', qris_expires_at: new Date(Date.now() + 3600000).toISOString(), ...over,
  });
  it('invoice tidak ada: 404', async () => {
    expect((await order('INV-NOPE')).status).toBe(404);
  });
  it('PENDING yang belum lewat batas tetap PENDING', async () => {
    h.state.orders = [base()];
    const r = await order('INV-1');
    expect(r.json.order.payment_status).toBe('PENDING'); expect(h.state.updates.orders).toHaveLength(0);
  });
  it('PENDING yang sudah lewat 1 jam berubah menjadi EXPIRED dan disimpan', async () => {
    h.state.orders = [base({ qris_expires_at: new Date(Date.now() - 1000).toISOString() })];
    const r = await order('INV-1');
    expect(r.json.order.payment_status).toBe('EXPIRED');
    expect(h.state.updates.orders[0].patch).toEqual({ payment_status: 'EXPIRED' });
  });
  it('PAID tidak diubah meski waktunya lewat', async () => {
    h.state.orders = [base({ payment_status: 'PAID', qris_expires_at: new Date(Date.now() - 1000).toISOString() })];
    expect((await order('INV-1')).json.order.payment_status).toBe('PAID');
  });
  it('[TEMUAN] respons publik tidak boleh memuat email pembeli (endpoint tanpa autentikasi)', async () => {
    h.state.orders = [base()];
    const r = await order('INV-1');
    expect(JSON.stringify(r.json)).not.toContain('pembeli@gmail.com');
  });
});
