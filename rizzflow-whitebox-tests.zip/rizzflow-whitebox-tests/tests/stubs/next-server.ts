// Stub ringan untuk 'next/server' agar logika route bisa diuji tanpa menjalankan Next.js
export class NextResponse {
  status: number;
  private _body: unknown;
  constructor(body: unknown, init?: { status?: number }) {
    this._body = body;
    this.status = init?.status ?? 200;
  }
  static json(body: unknown, init?: { status?: number }) {
    return new NextResponse(body, init);
  }
  async json() {
    return this._body;
  }
}
