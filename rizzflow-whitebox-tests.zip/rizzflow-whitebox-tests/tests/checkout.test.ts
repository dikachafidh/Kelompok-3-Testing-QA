import { describe, it, expect, vi, beforeEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { newState, makeClient, type FakeState } from './helpers/fakeSupabase';

const h = vi.hoisted(() => ({ state: null as any, makeClient: null as any, notify: vi.fn(), backup: vi.fn(), qris: vi.fn() }));

vi.mock('@/lib/supabase', () => ({
  getSupabaseAdmin: () => h.makeClient(h.state),
  sendAdminTelegramNotification: h.notify,
  saveOrderItemsBackup: h.backup,
}));
vi.mock('@/lib/doku', async (orig) => {
  const actual: any = await orig();
  return { ...actual, createDokuQrisPayment: h.qris };
});

import { POST } from '@/app/api/checkout/route';
import { calculatePromoDiscount } from '@/lib/doku';

const P1 = { id: 'p1', title: 'Template Excel UMKM', price: 19000, is_active: true };
const P2 = { id: 'p2', title: 'E-Book', price: 5000, is_active: true };
const promoRow = (over: any = {}) => ({
  id: 'x', code: 'HEMAT20', discount_percent: 20, max_discount_amount: 15000,
  starts_at: '2020-01-01T00:00:00Z', expires_at: '2099-01-01T00:00:00Z', is_active: true, ...over,
});

async function checkout(body: any) {
  const res: any = await POST(new Request('http://localhost/api/checkout', { method: 'POST', body: JSON.stringify(body) }));
  return { status: res.status as number, json: (await res.json()) as any };
}
const ok = (over: any = {}) => ({ customer_email: 'a@gmail.com', items: [{ product_id: 'p1', quantity: 1 }], ...over });

beforeEach(() => {
  h.makeClient = makeClient;
  h.state = newState({ products: [P1, P2] });
  h.notify.mockReset(); h.backup.mockReset();
  h.qris.mockReset(); h.qris.mockResolvedValue({ qris_string: 'QR', expires_at: new Date(Date.now() + 3600000).toISOString() });
});

describe('validasi email (cabang validateEmailFormat)', () => {
  it.each([
    ['kosong', '', /wajib diisi/],
    ['hanya spasi', '   ', /wajib diisi/],
    ['mengandung spasi', 'a b@gmail.com', /spasi/],
    ['tanpa @', 'abcgmail.com', /tepat satu/],
    ['dua @', 'a@b@gmail.com', /tepat satu/],
    ['nama lokal kosong', '@gmail.com', /sebelum tanda/],
    ['domain tanpa titik', 'a@gmail', /domain email/],
    ['domain diawali titik', 'a@.gmail.com', /domain email/],
    ['domain berakhir titik', 'a@gmail.com.', /domain email/],
    ['domain diawali tanda hubung', 'a@-gmail.com', /domain email/],
    ['domain titik ganda', 'a@gm..ail.com', /domain email/],
    ['TLD 1 huruf', 'a@gmail.c', /Akhiran domain/],
  ])('menolak email %s', async (_n, email, msg) => {
    const r = await checkout(ok({ customer_email: email }));
    expect(r.status).toBe(400); expect(r.json.error).toMatch(msg);
  });
  it('menerima email valid dan menormalkan huruf kecil', async () => {
    const r = await checkout(ok({ customer_email: '  USER@Gmail.COM ' }));
    expect(r.status).toBe(200); expect(r.json.order.customer_email).toBe('user@gmail.com');
  });
  it('batas: TLD tepat 2 huruf diterima', async () => {
    expect((await checkout(ok({ customer_email: 'a@b.id' }))).status).toBe(200);
  });
  it('[TEMUAN] email sangat panjang (250+ karakter) seharusnya ditolak', async () => {
    const long = 'a'.repeat(250) + '@gmail.com';
    expect((await checkout(ok({ customer_email: long }))).status).toBe(400);
  });
});

describe('keranjang dan produk', () => {
  it('menolak keranjang kosong dan body tanpa items', async () => {
    expect((await checkout({ customer_email: 'a@gmail.com', items: [] })).status).toBe(400);
    expect((await checkout({ customer_email: 'a@gmail.com' })).status).toBe(400);
  });
  it('menolak jika tidak ada produk aktif yang cocok', async () => {
    h.state.products = [];
    const r = await checkout(ok());
    expect(r.status).toBe(400); expect(r.json.error).toMatch(/tidak ditemukan/);
  });
  it('menghitung subtotal = harga x jumlah (beberapa item)', async () => {
    const r = await checkout(ok({ items: [{ product_id: 'p1', quantity: 2 }, { product_id: 'p2', quantity: 1 }] }));
    expect(r.json.order.subtotal_amount).toBe(19000 * 2 + 5000);
    expect(r.json.order.final_amount).toBe(43000);
  });
  it.each([[0, 1], [-5, 1], ['abc', 1], [undefined, 1]])('jumlah %s dikoreksi menjadi %s', async (q, expected) => {
    const r = await checkout(ok({ items: [{ product_id: 'p2', quantity: q }] }));
    expect(r.json.order.subtotal_amount).toBe(5000 * (expected as number));
  });
  it('[TEMUAN] jumlah pecahan (1.5) seharusnya ditolak/dibulatkan menjadi bilangan bulat', async () => {
    await checkout(ok({ items: [{ product_id: 'p2', quantity: 1.5 }] }));
    const qty = h.state.inserts.order_items[0]?.quantity;
    expect(Number.isInteger(qty)).toBe(true);
  });
  it('[TEMUAN] jumlah sangat besar (1 miliar) seharusnya dibatasi', async () => {
    const r = await checkout(ok({ items: [{ product_id: 'p2', quantity: 1_000_000_000 }] }));
    expect(r.status).toBe(400);
  });
  it('produk tidak dikenal dilewati diam-diam bila ada produk lain yang valid (perilaku saat ini)', async () => {
    const r = await checkout(ok({ items: [{ product_id: 'ghost', quantity: 1 }, { product_id: 'p2', quantity: 1 }] }));
    expect(r.status).toBe(200); expect(r.json.order.subtotal_amount).toBe(5000);
  });
  it('produk yang sama dua kali dihitung dua kali (perilaku saat ini)', async () => {
    const r = await checkout(ok({ items: [{ product_id: 'p2', quantity: 1 }, { product_id: 'p2', quantity: 1 }] }));
    expect(r.json.order.subtotal_amount).toBe(10000);
  });
});

describe('promo dan total akhir', () => {
  it('menerapkan diskon persen dengan batas maksimal', async () => {
    h.state.promo = promoRow();
    const r = await checkout(ok({ items: [{ product_id: 'p1', quantity: 10 }], promo_code: 'hemat20' })); // 190000 -> 20% = 38000, cap 15000
    expect(r.json.order.discount_amount).toBe(15000); expect(r.json.order.final_amount).toBe(175000);
  });
  it('promo kedaluwarsa diabaikan tanpa pesan galat (perilaku saat ini)', async () => {
    h.state.promo = promoRow({ expires_at: '2021-01-01T00:00:00Z' });
    const r = await checkout(ok({ promo_code: 'HEMAT20' }));
    expect(r.status).toBe(200); expect(r.json.order.discount_amount).toBe(0);
  });
  it('total akhir tidak pernah di bawah Rp1.000 (diskon 100%)', async () => {
    h.state.promo = promoRow({ discount_percent: 100, max_discount_amount: 0 });
    const r = await checkout(ok({ items: [{ product_id: 'p2', quantity: 1 }], promo_code: 'FREE' }));
    expect(r.json.order.final_amount).toBe(1000);
  });
  it('[TEMUAN] kode promo yang dipakai seharusnya tersimpan di kolom promo_code_used', async () => {
    h.state.promo = promoRow();
    await checkout(ok({ promo_code: 'HEMAT20' }));
    expect(h.state.inserts.orders[0].promo_code_used).toBe('HEMAT20');
  });
});

describe('konsistensi hitungan promo: pratinjau (validate) vs checkout', () => {
  const cases = [
    { name: 'pembulatan pecahan 1250 x 15%', subtotal: 1250, pct: 15, cap: 999999 },
    { name: 'max_discount_amount = 0 (tanpa batas?)', subtotal: 100000, pct: 10, cap: 0 },
    { name: 'kasus normal 100000 x 20% cap 15000', subtotal: 100000, pct: 20, cap: 15000 },
  ];
  it.each(cases)('diskon sama untuk: $name', async ({ subtotal, pct, cap }) => {
    const row = promoRow({ discount_percent: pct, max_discount_amount: cap });
    h.state.products = [{ id: 'big', title: 'X', price: subtotal, is_active: true }];
    h.state.promo = row;
    const r = await checkout(ok({ items: [{ product_id: 'big', quantity: 1 }], promo_code: 'HEMAT20' }));
    const preview = calculatePromoDiscount(subtotal, row as any).discount_amount;
    expect(r.json.order.discount_amount).toBe(preview);
  });
});

describe('galat dan integrasi', () => {
  it('galat dari DOKU menghasilkan 500', async () => {
    h.qris.mockRejectedValue(new Error('DOKU down'));
    const r = await checkout(ok());
    expect(r.status).toBe(500); expect(r.json.error).toBe('DOKU down');
  });
  it('[TEMUAN] pesan galat internal tidak boleh dikirim apa adanya ke pembeli', async () => {
    h.qris.mockRejectedValue(new Error('Gagal membuat QRIS DOKU: {"secret":"detail internal"}'));
    const r = await checkout(ok());
    expect(r.json.error).not.toMatch(/DOKU|secret|detail internal/);
  });
  it('gagal menyimpan pesanan menghasilkan 500', async () => {
    h.state.orderInsertError = { message: 'db error' };
    expect((await checkout(ok())).status).toBe(500);
  });
  it('format nomor invoice INV-<timestamp>-<3 digit>', async () => {
    const r = await checkout(ok());
    expect(r.json.order.invoice_number).toMatch(/^INV-\d{13}-\d{3}$/);
  });
  it('item pesanan dicadangkan ke storage dan notifikasi admin terkirim', async () => {
    await checkout(ok());
    expect(h.backup).toHaveBeenCalledTimes(1); expect(h.notify).toHaveBeenCalledTimes(1);
  });
  it('body bukan JSON menghasilkan 500', async () => {
    const res: any = await POST(new Request('http://localhost/api/checkout', { method: 'POST', body: 'bukan json' }));
    expect(res.status).toBe(500);
  });
  it('mode simulasi tercermin pada respons', async () => {
    vi.stubEnv('DOKU_SIMULATION_MODE', 'true');
    expect((await checkout(ok())).json.simulation_mode).toBe(true);
    vi.unstubAllEnvs();
  });
});

describe('kontrak skema database (schema.sql vs kode)', () => {
  const sql = fs.readFileSync(path.resolve(__dirname, '../supabase/schema.sql'), 'utf8');
  const cols = (table: string) => {
    const m = sql.match(new RegExp(`CREATE TABLE IF NOT EXISTS public\\.${table} \\(([\\s\\S]*?)\\n\\);`));
    return new Set((m?.[1] || '').split('\n').map((l) => l.trim().match(/^([a-z_]+)\s/)?.[1]).filter(Boolean) as string[]);
  };
  it('[TEMUAN] kolom yang dimasukkan ke order_items ada di schema.sql', async () => {
    await checkout(ok());
    const keys = Object.keys(h.state.inserts.order_items[0]);
    const missing = keys.filter((k) => !cols('order_items').has(k));
    expect(missing).toEqual([]); // kode memakai price_at_purchase, skema memakai unit_price
  });
  it('kolom yang dimasukkan ke orders ada di schema.sql', async () => {
    await checkout(ok());
    const keys = Object.keys(h.state.inserts.orders[0]);
    expect(keys.filter((k) => !cols('orders').has(k))).toEqual([]);
  });
});
