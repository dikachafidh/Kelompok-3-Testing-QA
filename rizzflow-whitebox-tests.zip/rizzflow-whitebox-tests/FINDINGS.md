# Temuan White Box — RizzFlow (dari kode dan test otomatis)

Status: **hasil dari kode yang diunggah dan test pada lingkungan simulasi**. Belum diverifikasi pada sistem berjalan. Verifikasi pada lingkungan lokal/staging, bukan pada situs produksi.

| ID | Temuan | Bukti (test yang gagal) | Severity usulan | Saran perbaikan |
|---|---|---|---|---|
| W-01 | Endpoint `GET /api/orders/[invoice]` tanpa autentikasi mengembalikan seluruh data pesanan, termasuk `customer_email` dan `qris_string`. Nomor invoice berbentuk `INV-<timestamp>-<3 digit>` sehingga dapat ditebak. | promo-orders.test.ts: "respons publik tidak boleh memuat email pembeli" | Tinggi | Kembalikan hanya status dan nominal; gunakan token acak panjang (mis. UUID) pada invoice atau tautan status. |
| W-02 | Kolom `order_items` tidak cocok dengan skema: kode memasukkan `price_at_purchase`, skema `schema.sql` mendefinisikan `unit_price NOT NULL`. Kegagalan insert tidak dicek, sehingga item pesanan bisa tidak tersimpan (kode hanya mengandalkan cadangan di storage). | checkout.test.ts: "kolom yang dimasukkan ke order_items ada di schema.sql" | Tinggi | Samakan nama kolom (kode atau skema) dan periksa `error` hasil insert; verifikasi terhadap database nyata. |
| W-03 | Webhook tidak membandingkan `order.amount` dengan `final_amount` pesanan. | webhook.test.ts: "nominal pada webhook harus sama dengan final_amount" | Sedang | Tolak webhook jika nominal tidak sama. |
| W-04 | Pemeriksaan-lalu-update status pesanan tidak atomik: dua webhook bersamaan untuk invoice sama sama-sama membaca PENDING dan mengirim email dua kali. | webhook.test.ts: "dua webhook bersamaan ... hanya satu email" | Sedang | Update bersyarat (`UPDATE ... WHERE payment_status='PENDING'`) lalu lanjut hanya jika ada baris terubah. |
| W-05 | Pada mode simulasi, header `Signature: SIMULATION_BYPASS` melewati verifikasi webhook. Aman hanya jika `DOKU_SIMULATION_MODE` tidak `true` di produksi. (Test untuk mode produksi LULUS: bypass ditolak.) | webhook.test.ts (lulus) | Kritis jika env salah | Pastikan variabel itu tidak aktif di produksi; pertimbangkan menolak bypass saat `NODE_ENV=production`. |
| W-06 | `max_discount_amount = 0` diperlakukan "tanpa batas" oleh checkout, tetapi jadi diskon 0 oleh pratinjau `calculatePromoDiscount`. Pembulatan juga beda (`Math.round` di checkout, `Math.floor` di pratinjau). Pembeli melihat potongan berbeda dari yang ditagih. | doku.test.ts dan checkout.test.ts (2 kasus konsistensi) | Sedang | Satu fungsi hitung bersama dipakai kedua tempat; tetapkan arti nilai 0. |
| W-07 | Jumlah (`quantity`) tidak dibatasi dan boleh pecahan; skema database memakai INTEGER. | checkout.test.ts: pecahan 1.5; jumlah 1 miliar | Sedang | Validasi bilangan bulat dengan batas atas (mis. 1–10). |
| W-08 | Pesan galat internal (mis. respons DOKU) diteruskan ke pembeli pada status 500. | checkout.test.ts: "pesan galat internal tidak boleh dikirim" | Sedang | Kembalikan pesan umum; catat detail di log server. |
| W-09 | Respons DOKU tanpa `qr_string`/`url` diganti string QR buatan (`RIZZFLOW-QRIS-<invoice>`), pesanan tetap dibuat. | doku.test.ts: "respons DOKU tanpa qr_string ... QR palsu" | Sedang | Lempar galat dan jangan buat pesanan. |
| W-10 | Kode promo yang dipakai tidak disimpan ke `orders.promo_code_used` walau kolomnya ada. | checkout.test.ts: "tersimpan di promo_code_used" | Rendah | Sertakan `promo_code_used: appliedPromoCode` pada insert. |
| W-11 | `POST /api/promo/validate` dengan `subtotal: "abc"` lolos (NaN) dan menghasilkan pesan "Hemat RpNaN". | promo-orders.test.ts: "subtotal bukan angka" | Rendah | Periksa `Number.isFinite(subtotal)`. |
| W-12 | Email pembeli tidak dibatasi panjangnya. | checkout.test.ts: "email sangat panjang" | Rendah | Batasi (mis. 254 karakter). |

## Observasi dari kode yang belum punya test otomatis
- Tidak ada pembatasan laju (rate limit) atau CAPTCHA pada `POST /api/checkout`: setiap permintaan membuat pesanan dan tagihan QRIS baru.
- Format invoice `INV-<ms>-<100..999>` bisa bertabrakan pada permintaan bersamaan (ada batas UNIQUE di database, tetapi galatnya akan muncul sebagai 500).
- `verifyDokuWebhookSignature` di `lib/doku.ts` tidak dipakai route webhook (route memiliki salinan sendiri): duplikasi kode yang rawan tidak sinkron.
- Perbandingan signature memakai `===` (bukan perbandingan waktu-konstan).
- Webhook tetap menyatakan `PAID_AND_DELIVERED` walau email gagal (hanya `email_status` yang menandai peringatan).

## Hasil analisis statis (18 November 2026)
Dijalankan setelah `npm install` pada salinan kode (Next 16.4.4, TypeScript 5, ESLint 9). Kode pada dua unggahan zip identik (checksum sama).

| ID | Pemeriksaan | Hasil | Catatan |
|---|---|---|---|
| - | `tsc --noEmit` | 0 galat | Lulus |
| S-01 | `eslint` (eslint-config-next) | 34 berkas: 6 error, 13 peringatan | 6 error `react-hooks/set-state-in-effect` (setState langsung di dalam `useEffect`): `checkout/page.tsx:137`, `admin/page.tsx:141`, `AdminPromosSettingsTab.tsx:71`, `ProductDetailSheet.tsx:42`, `ShopTabView.tsx:56`, `StorefrontClient.tsx:122`. 13 peringatan `no-img-element` pada 8 berkas. |
| S-02 | `npm audit --omit=dev` | 1 kerentanan moderat | Next 16.2.0–16.4.4, dua advisory terkait `use cache`/`unstable_cache`. Fitur itu tidak ditemukan di `src`, dampak kemungkinan kecil. Perbaikan: Next 16.4.6. |
| S-03 | ESLint rule `complexity` (ambang 10) | 32 fungsi melebihi ambang | Tertinggi: `api/messages/route.ts` (52), `ServicesTabView.tsx` (45), `AdminPromosSettingsTab.tsx` (39), `AdminServicesTab.tsx` (36), `AdminCatalogTab.tsx` (30), `webhooks/doku/route.ts` (27), `checkout/route.ts` (25). Rute `messages` belum dicakup test: prioritas berikutnya. |
