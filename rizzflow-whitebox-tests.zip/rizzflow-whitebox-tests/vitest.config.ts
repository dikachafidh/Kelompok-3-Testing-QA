import { defineConfig } from 'vitest/config';
import path from 'node:path';

export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
      'next/server': path.resolve(__dirname, 'tests/stubs/next-server.ts'),
    },
  },
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      reportOnFailure: true,
      include: ['src/lib/doku.ts', 'src/app/api/checkout/route.ts', 'src/app/api/promo/validate/route.ts', 'src/app/api/orders/**/route.ts', 'src/app/api/webhooks/doku/route.ts'],
      reporter: ['text', 'json-summary'],
    },
  },
});
