# White Box Test Suite — RizzFlow

Test otomatis (Vitest) untuk logika server RizzFlow: library DOKU, API checkout, validasi promo, cek pesanan, dan webhook pembayaran.
Dibuat dari pembacaan source code `RizzFlow-main` (Next.js + Supabase + DOKU).

## Cara memakai di proyek RizzFlow
1. Salin folder `tests/` dan berkas `vitest.config.ts` ke akar proyek (sejajar `package.json` dan folder `src/`, `supabase/`).
2. Pasang alat uji (hanya devDependency):
   ```bash
   npm install -D vitest@^3 @vitest/coverage-v8@^3
   ```
3. Jalankan:
   ```bash
   npx vitest run               # seluruh test
   npx vitest run --coverage    # dengan laporan coverage (statement, branch, function)
   ```

## Catatan
- Test memakai Supabase palsu di memori (`tests/helpers/fakeSupabase.ts`), `next/server` diganti stub ringan (`tests/stubs/next-server.ts`), dan DOKU/email/Telegram di-mock. Tidak ada koneksi ke internet atau database nyata, jadi aman dijalankan kapan saja dan **tidak menyentuh situs produksi**.
- Test berlabel `[TEMUAN]` menyatakan perilaku yang *seharusnya* terjadi. Jika test itu **gagal**, berarti kode saat ini menyimpang dari perilaku tersebut (lihat `FINDINGS.md`). Setelah kode diperbaiki, test akan lulus.
- Test lain mendokumentasikan perilaku saat ini (bertanda "perilaku saat ini") atau memeriksa cabang logika biasa.
- Kontrak skema (`checkout.test.ts`, bagian terakhir) membaca `supabase/schema.sql` dan membandingkannya dengan kolom yang dimasukkan kode.

## Hasil eksekusi (15 November 2026 untuk test; 18 November 2026 untuk analisis statis, pada kode `RizzFlow-main` yang diunggah)
- 95 test: 81 lulus, 14 gagal (seluruhnya adalah temuan pada `FINDINGS.md`).
- Coverage berkas yang diuji: statement 95,4%, branch 87,66%, function 100%; `src/lib/doku.ts` 100%.
- Berkas yang belum tercakup: komponen React (storefront/admin), `src/lib/supabase.ts`, `src/lib/email.ts`, `src/app/api/messages`, `src/app/api/admin/resend-email`.
- Analisis statis: `tsc --noEmit` 0 galat; ESLint 6 error dan 13 peringatan; `npm audit` 1 kerentanan moderat (Next, fitur terkait tidak dipakai); 32 fungsi berkompleksitas siklomatik > 10 (lihat `FINDINGS.md`).
